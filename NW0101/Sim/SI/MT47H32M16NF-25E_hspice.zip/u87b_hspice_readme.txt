U87B HSPICE MODEL 
-----------------
Device: 512Mb DDR2 SDRAM - Die Revision "H" 
Architecture: 128Meg x 4, 64Meg x 8, 32Meg x 16
VDD/VDDQ: 1.7V-1.9V


SOURCE
------------
Micron Technology, Inc.
For support send e-mail to modelsupport@micron.com     


REVISION HISTORY
----------------
Rev 1.0: 6/19/2013
       - Initial pre silicon model
       - Model matched to IBIS model revision 1.0
Rev 2.0: 12/04/2013
       - Model matched to silicon measurements
       - Model matched to IBIS model revision 2.0

FILES
------------
u87b_dqbuff.inc   Encrypted net-list for DQ I/O's  
u87b_dmbuff.inc   Encrypted net-list for DM Inputs
u87b_dqsbuff.inc  Encrypted net-list for DQS I/O's 
u87b_rdqsbuff.inc Encrypted net-list for RDQS Output 
u87b_clkbuff.inc  Encrypted net-list for CLK and CLK# Inputs 
u87b_inbuff.inc   Encrypted net-list for all Inputs except CLK, CLK# and DM 

u87b_dq.sp        HSPICE deck file to run a test simulation using u87b_dqbuff.inc netlist
u87b_dm.sp        HSPICE deck file to run a test simulation using u87b_dmbuff.inc netlist
u87b_dqs.sp       HSPICE deck file to run a test simulation using u87b_dqsbuff.inc netlist 
u87b_rdqs.sp      HSPICE deck file to run a test simulation using u87b_rdqsbuff.inc netlist 
u87b_clk.sp       HSPICE deck file to run a test simulation using u87b_clkbuff.inc netlist 
u87b_input.sp     HSPICE deck file to run a test simulation using u87b_inbuff.inc netlist
u87b_model.cnr    File to select typical, weak or strong process

u87b_hspice_readme.txt            Read me file

u87b_ext_model_quality_rpt_rev2p1.pdf    Model Quality Report


INSTRUCTIONS
------------
- To run test simulation using the spice deck file, the files "u87b_model.cnr" 
  and encrypted netlist are required to be in the same directory. 

- Commercial temperature settings are: Typical 50C, Slow 100C, Fast 0C
  Industrial temperature settings are: Typical 50C, Slow 110C, Fast -40C
  Automotive temperature settings are: Typical 50C, Slow 120C, Fast -40C

- The spice netlists are not designed to match datasheet timing numbers. 
  Delay times are smaller than those given in the data sheets.

- VCCQ/VSSQ decoupling capacitance is included in the DQ, DQS, RDQS and DM models
      DQ    = 430pF
      DQS   = 430pF x 2(DQS/DQS#) = 860pF
      Total = 430pF x 16(DQ) + 860pF x 4(DQS/DQS#) + 430pF x 3(DM/RDQS#) = 9.89nF 

- The .LIB statement selects the following simulation corners:
      LIB        DATARATE       PROCESS  DIE CAP  VDD/VDDQ
      ---        --------       -------  -------  --------
      TYP_533    400/533 Mbps   Typical  Typical  1.800V
      SLOW_533   400/533 Mbps   Weak     Maximum  1.700V
      FAST_533   400/533 Mbps   Strong   Minimum  1.900V
   
      TYP_667    667 Mbps       Typical  Typical  1.800V
      SLOW_667   667 Mbps       Weak     Maximum  1.700V
      FAST_667   667 Mbps       Strong   Minimum  1.900V
   
      TYP_800    800 Mbps       Typical  Typical  1.800V
      SLOW_800   800 Mbps       Weak     Maximum  1.700V
      FAST_800   800 Mbps       Strong   Minimum  1.900V
   
      TYP_1066   1066 Mbps      Typical+ Typical  1.800V
      SLOW_1066  1066 Mbps      Weak+    Maximum  1.700V
      FAST_1066  1066 Mbps      Strong   Minimum  1.900V

- Please refer to the IBIS model for specific package parasitic values.

- This part uses an internally regulated voltage (vccr).
        ( min / typ / max )
  VCCR = 1.25V/1.30V/1.35V


NOTES
------------
1. Be advised that due to a bug in HSPICE versions 2006.03 and 2005.09
simulations with multiple calls to the same encrypted subcircuit in the same 
spice deck file (.sp file) may produce incorrect simulation results.  This bug 
is not found in older versions of HSPICE such as 2005.03 or newer versions 
such as 2006.03-SP1 and 2006.09.


PART NUMBER        VDD/VDDQ    Architecture   Package
-----------        --------    ------------   -------
MT47H128M4SH       1.8V/1.8V   128Meg x 4     60-Ball FBGA 8mm X 10mm
MT47H64M8SH        1.8V/1.8V   64Meg x 8      60-Ball FBGA 8mm X 10mm
MT47H32M16NF       1.8V/1.8V   32Meg x 16     84-Ball FBGA 8mm x 12.5mm
MT47H128M4U87B     1.8V/1.8V   128Meg x 4     Bare Die
MT47H64M8U87B      1.8V/1.8V   64Meg x 8      Bare Die 
MT47H32M16U87B     1.8V/1.8V   32Meg x 16     Bare Die 


[Disclaimer] This software code and all associated documentation, comments
             or other information (collectively "Software") is provided 
             "AS IS" without warranty of any kind. MICRON TECHNOLOGY, INC. 
             ("MTI") EXPRESSLY DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED,
             INCLUDING BUT NOT LIMITED TO, NONINFRINGEMENT OF THIRD PARTY
             RIGHTS, AND ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS
             FOR ANY PARTICULAR PURPOSE. MTI DOES NOT WARRANT THAT THE
             SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF
             THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE,
             MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE
             RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS,
             ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT
             OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO
             EVENT SHALL MTI, ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE
             LIABLE FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR
             SPECIAL DAMAGES (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
             OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF INFORMATION)
             ARISING OUT OF YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
             EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
             Because some jurisdictions prohibit the exclusion or limitation
             of liability for consequential or incidental damages, the above
             limitation may not apply to you.
 
             Copyright 2013 Micron Technology, Inc. All rights reserved.
