/**
 * \file
 * \author      Nabeel Ahmed
 */

#ifndef BLE_LINK_LIST_H__
#define BLE_LINK_LIST_H__

#include <stdint.h>
#include <stdbool.h>

typedef struct ble_node {
   uint8_t ble_addr[6];
   uint8_t conn_handle;
   struct ble_node *next;
} ble_node_t;



void insert_first_ble_node(uint8_t conn_handle, uint8_t ble_addr[]);

ble_node_t* delete_first_ble_node(void);

bool no_ble_nodes(void);

ble_node_t* find_ble_node(uint8_t conn_handle);

ble_node_t* delete_ble_node(uint8_t conn_handle);

void sort_ble_nodes_list(void);

void reverse_ble_nodes_list(ble_node_t** head_ref) ;

#endif //BLE_LINK_LIST_H__
