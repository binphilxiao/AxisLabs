/**
 * \file
 * \author      Sungjune Lee
 * \brief	    Uart packet encoder/ coder
 *
 * This program decodes payload from the uart data stream. It also encodes
 * payload data into a packet.
 *
 * The structure of the packet is as follows:
 *
 \verbatim
 (header) (size) (payload) (checksum)
 \endverbatim
 *
 * \b (header), \b (size), and \b (checksum) are all one byte in size.
 * The size byte represents the length of the payload only.
 *
 */

#ifndef __PACKET_HANDLER_H__
#define __PACKET_HANDLER_H__

#include <stdint.h>
#include <stdbool.h>

#define MAX_PAYLOAD		253					///< max size of the payload
#define MAX_PACKET		(MAX_PAYLOAD + 3)   ///< max size of the packet

#define PKT_HEADR		0xf5				///< packet header signature
#define PKT_ACK			0xf6				///< ACK packet
#define PKT_NAK			0xf7				///< NAK packet

/// Packet state machine return value
typedef enum
{
	PKT_WAITING  = 0,	///< waiting for a packet
    PKT_PROCESSING,		///< packet is being received
    PKT_RECEIVED,		///< valid packet received
    ACK_RECEIVED,		///< ACK packet received
    NAK_RECEIVED,		///< NAK packet received
    PKT_SIZE_ERR,		///< packet size error detected
    PKT_CSUM_ERR,		///< checksum error detected
} pkt_status;


/// Packet decoding state machine
pkt_status packet_decoder(uint8_t byte, uint8_t *payload, uint8_t *size);
pkt_status packet_decoder_dfu_mode(uint8_t byte, uint8_t *payload, uint8_t *size);
/// Packet encoder
int packet_encoder(uint8_t *payload, int size, uint8_t *packet);

#endif // __PACKET_HANDLER_H__
