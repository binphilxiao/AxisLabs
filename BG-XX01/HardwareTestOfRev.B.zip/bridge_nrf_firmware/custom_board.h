/**
 * 
 */
#ifndef GRV2_BOARD_H
#define GRV2_BOARD_H

#ifdef __cplusplus
extern "C" {
#endif

#include "nrf_gpio.h"

/// PWM LEDs definitions for Gear V2 Custom Board
#define LEDS_NUMBER        1

#define LED_RING            NRF_GPIO_PIN_MAP(0,14)

/// LED control outputs
#define LED_RING_SWITCH     NRF_GPIO_PIN_MAP(0,15)   

#define LEDS_ACTIVE_STATE 0

#define LEDS_LIST { LED_RING }

#define BSP_LED_0      LED_RING

/// Buttons definitions for Gear V2 Custom Board
#define BUTTONS_NUMBER   0

/// Boot Signal
#define BOOT_SIGNAL_MT76    NRF_GPIO_PIN_MAP(0, 13)

/// UART
 #define RX_PIN_NUMBER  8
 #define TX_PIN_NUMBER  6
 #define CTS_PIN_NUMBER 7
 #define RTS_PIN_NUMBER 5
 #define HWFC           false

/// QSPI
 #define BSP_QSPI_SCK_PIN   25
 #define BSP_QSPI_CSN_PIN   31
 #define BSP_QSPI_IO0_PIN   20
 #define BSP_QSPI_IO1_PIN   21
 #define BSP_QSPI_IO2_PIN   22
 #define BSP_QSPI_IO3_PIN   23

/// Digital Lines
#define PWM_LED_RING_PIN            NRF_GPIO_PIN_MAP(0, 14) 

/// Analog Lines
// #define ARDUINO_A0_PIN              3     // Analog channel 0
// #define ARDUINO_A1_PIN              4     // Analog channel 1
// #define ARDUINO_A2_PIN              28    // Analog channel 2
// #define ARDUINO_A3_PIN              29    // Analog channel 3
// #define ARDUINO_A4_PIN              30    // Analog channel 4
// #define ARDUINO_A5_PIN              31    // Analog channel 5


#ifdef __cplusplus
}
#endif

#endif // GRV2_BOARD_H
