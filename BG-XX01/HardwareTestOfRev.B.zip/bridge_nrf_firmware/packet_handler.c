/**
 * \file
 * \author      Sungjune Lee
 */
#include "packet_handler.h"
#include "nrf_log.h"

// packet decoding state machine states
#define PKT_STATE_HDR           0
#define PKT_STATE_LEN           1
#define PKT_STATE_PLD           2
#define PKT_STATE_CSM           3

/**
 * This function runs the packet decoding state machine. It takes stream of
 * UART data one byte at a time and returns the current state of the state
 * machine. Upon successful retrieval of a packet, it fills the array buffer[]
 * with the payload.
 *
 * To use this function, define an uint8_t array for the payload storage and call
 * this function whenever new byte is arrived. The best place to put this
 * function is inside of the UART check routine (not inside the interrupt
 * service callback function).
 *
\code
uint8_t payload[MAX_PAYLOAD];
uint16_t size;
pkt_status pstatus;

if(UART_RX_flag_is_set)
{
    // new data byte is in new_byte
    if(PKT_RECEIVED == packet_decoder(new_byte, payload, &size))
    {
        // your data is in the payload whose length is size byte
    }
}
\endcode
 *
 * \param	byte received byte
 * \param   payload retrieved packet
 * \param   size size of the packet
 * \return  pkt_status status of the state machine
 */
pkt_status packet_decoder(uint8_t byte, uint8_t *payload, uint8_t *size)
{
    static uint8_t state = PKT_STATE_HDR;
    static uint8_t len = 0;
    static uint8_t index = 0;
    static uint8_t buffer[MAX_PAYLOAD] = {0};
	static uint8_t csum = 0;

    uint8_t i;

    // waiting for the header byte
    if(state == PKT_STATE_HDR)
    {
		// header received
        if(byte == PKT_HEADR)
        {
            // proceed to the next state
            state = PKT_STATE_LEN;
        }
		// ACK received
        else if(byte == PKT_ACK)
        {
            // ACK received but do not change the state
            return ACK_RECEIVED;
        }
		// NAK received
        else if(byte == PKT_NAK)
        {
            // NAK received but do not change the state
            return NAK_RECEIVED;
        }
        else
        {
                // no valid header received so far
                return PKT_WAITING;
        }
    }
    // waiting for the length byte
    else if(state == PKT_STATE_LEN)
    {
        // save the length of the payload
        len = byte;

        // invalid size
        if(len > MAX_PAYLOAD)
        {
            // start all over
            state = PKT_STATE_HDR;
            // report size error
            return PKT_SIZE_ERR;
        }
        // length byte is valid
        else
        {
            // clear index
            index = 0;
            // clear payload buffer
            for(i = 0; i < MAX_PAYLOAD; i++)
            {
                buffer[i] = 0;
            }
            // proceed to the next state
            state = PKT_STATE_PLD;
        }
    }
    // waiting for the payload
    else if(state == PKT_STATE_PLD)
    {
        // collecte data
        buffer[index++] = byte;
        // proceed to the next if all payload is collected
        if(index == len)
        {
            state = PKT_STATE_CSM;
        }
    }
    // waiting for the checksum byte
    else if(state == PKT_STATE_CSM)
    {
        csum = 0;
        for(i = 0; i < len; i++)
        {
                // copy buffer data to payload
                payload[i] = buffer[i];
                // compute checksum
                csum += buffer[i];
        }
        // size byte
        *size = (int)len;
        // start all over
        state = PKT_STATE_HDR;

        // compare checksum
        if(csum == byte)
        {
            // valid packet arrived
            return PKT_RECEIVED;
        }
        else
        {
            // checksum error
            NRF_LOG_INFO("csum %d", csum);
            return PKT_CSUM_ERR;
        }
    }

    return PKT_PROCESSING;
}

pkt_status packet_decoder_dfu_mode(uint8_t byte, uint8_t *payload, uint8_t *size)
{
    static uint8_t state = PKT_STATE_HDR;
    static uint8_t len = 0;
    static uint8_t index = 0;
    static uint8_t buffer[MAX_PAYLOAD] = {0};
	static uint8_t csum = 0;

    uint8_t i;

    // waiting for the header byte
    if(state == PKT_STATE_HDR)
    {
		// header received
        if(byte == PKT_HEADR)
        {
            // proceed to the next state
            state = PKT_STATE_LEN;
        }
		// ACK received
        else if(byte == PKT_ACK)
        {
            // ACK received but do not change the state
            return ACK_RECEIVED;
        }
		// NAK received
        else if(byte == PKT_NAK)
        {
            // NAK received but do not change the state
            return NAK_RECEIVED;
        }
        else
        {
                // no valid header received so far
                return PKT_WAITING;
        }
    }
    // waiting for the length byte
    else if(state == PKT_STATE_LEN)
    {
        // save the length of the payload
        len = byte;

        // invalid size
        if(len > MAX_PAYLOAD)
        {
            // start all over
            state = PKT_STATE_HDR;
            // report size error
            return PKT_SIZE_ERR;
        }
        // length byte is valid
        else
        {
            // clear index
            index = 0;
            // clear payload buffer
//            for(i = 0; i < MAX_PAYLOAD; i++)
//            {
//                buffer[i] = 0;
//            }
            // proceed to the next state
            state = PKT_STATE_PLD;
        }
    }
    // waiting for the payload
    else if(state == PKT_STATE_PLD)
    {
        // collecte data
        buffer[index++] = byte;
        // proceed to the next if all payload is collected
        if(index == len)
        {
            state = PKT_STATE_CSM;
        }
    }
    // waiting for the checksum byte
    else if(state == PKT_STATE_CSM)
    {
        csum = 0;
        for(i = 0; i < len; i++)
        {
                // copy buffer data to payload
                payload[i] = buffer[i];
                // compute checksum
                //csum += buffer[i];
                buffer[i] = 0;
        }
        // size byte
        *size = (int)len;
        // start all over
        state = PKT_STATE_HDR;

        // compare checksum
//        if(csum == byte)
//        {
            // valid packet arrived
            return PKT_RECEIVED;
//        }
//        else
//        {
//            // checksum error
//            NRF_LOG_INFO("csum %d", csum);
//            return PKT_CSUM_ERR;
//        }
    }

    return PKT_PROCESSING;
}

/**
 * This function constructs a packet from a payload.
 *
\code
int size = 10;
uint8_t payload[10];
utin8 packet[MAX_PKTSIZE];

# construct a packet
size = packet_encoder(payload, size, packet);
\endcode
 *
 * \param   payload payload
 * \param   size size of the payload
 * \param   packet resulting packet
 * \return  int the size of the resulting packet
 */
int packet_encoder(uint8_t *payload, int size, uint8_t *packet)
{
    uint8_t csum = 0;

    // header
    packet[0] = PKT_HEADR;
    // payload size
    packet[1] = size;
    // payload
    for(int i = 0; i < size; i++)
    {
		csum += payload[i];
        packet[2+i] = payload[i];
    }
    // checksum
    packet[2 + size] = csum;

    return (size + 3);
}

//------------------------------------------------------------------------------
#ifdef UNITTEST

#include <termios.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include "packet_handler.h"

// tty settings
#define BAUDRATE B115200
#define TTYDEVICE "/dev/ttyUSB0"

/// IO signal handler
void signal_handler (int status);

/// global variables
int wait_flag = true;

/**
 * signal handler. sets wait_flag to false, to indicate above loop that
 * characters have been received.
 */
void signal_handler (int status)
{
	wait_flag = false;
}


int main(void)
{
	int fd, res, size;
	struct termios tios;
	struct sigaction saio;
	pkt_status ps = PKT_WAITING;
	unsigned char buf[MAX_PACKET];
	unsigned char payload[MAX_PAYLOAD];

	// open the device to be non-blocking (read will return immediatly)
	fd = open(TTYDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK);

	if (fd <0)
	{
		perror(TTYDEVICE);
		exit(-1);
	}
	printf("\ntty device opened");

	// install the signal handler before making the device asynchronous
	saio.sa_handler = signal_handler;
	// with no mask: current serviced signal will be masked automatically
	sigemptyset(&saio.sa_mask);
	// clear other parameters
	saio.sa_flags = 0;
	saio.sa_restorer = NULL;
	// start sigaction
	sigaction(SIGIO, &saio, NULL);

	// allow the current process to receive SIGIO
	fcntl(fd, F_SETOWN, getpid());
	// make the file descriptor asynchronous
	fcntl(fd, F_SETFL, FASYNC);

	// control modes
	// - no harware flow control: ~CRTSCTS
	// - 8bit data: CS8
	// - one stop bits: ~CSTOPB
	// - no parity: ~PARENB
	// - enable receiver: CREAD
	// - ignore modem control lines: CLOCAL
	tios.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;

	// input modes
	// - ignore break: IGNBRK
	// - ignore framing errors and parity errors: IGNPAR
	tios.c_iflag = IGNBRK | IGNPAR;

	// output modes
	tios.c_oflag = 0;

	// local modes
	// - noncanonical mode: ~ICANON
	// - no echo: ~ECHO
	tios.c_lflag = 0;

	// special characters
	// - minimum number of characters for noncanonical read: VMIN
	// - time out in deciseconds for noncanocal read: VTIME
	tios.c_cc[VMIN] = 1;
	tios.c_cc[VTIME] = 0;

	// flush input buffer
	tcflush(fd, TCIFLUSH);
	// set termios parameter immediately
	tcsetattr(fd, TCSANOW, &tios);

	// loop
	while(true)
	{
		// pause until signaled
		//pause();

		// data is available
		if (wait_flag == false)
		{
			printf(".");
			// read data from the kernel buffer
			res = read(fd, buf, MAX_PACKET);
			// do something with the data
			for(int i = 0; i < res; i++)
			{
				ps = packet_decoder(buf[i], payload, &size);

				if(ps & (PKT_RECEIVED | ACK_RECEIVED | NAK_RECEIVED | \
							PKT_SIZE_ERR | PKT_CSUM_ERR))
				{
					break;
				}
			}

			// clear wait flag
			wait_flag = true;
		}

		if(ps == PKT_RECEIVED)
		{
			// print data
			printf("\n:");
			for(int i = 0; i < size; i++)
			{
				printf("0x%x.", payload[i]);
			}
		}
		else if(ps == ACK_RECEIVED)
		{
			printf("\nACK");
		}
		else if(ps == NAK_RECEIVED)
		{
			printf("\nNAK");
		}
		else if(ps == PKT_SIZE_ERR)
		{
			printf("\nWrong packet size");
		}
		else if(ps == PKT_CSUM_ERR)
		{
			printf("\nChecksum does not match");
		}


		if (ps != PKT_PROCESSING)
		{
			// construct a test packet
			size = 16;
			for(int i = 0; i < size; i++)
			{
				payload[i] = 0x40 + i;
			}
			size = packet_encoder(payload, size, buf);

			sleep(1);
			sleep(1);
			sleep(1);
			sleep(1);
			sleep(1);
			sleep(1);

			printf("\nsending packet");
			/*
			*/
			printf("\n");
			for(int i = 0; i < size; i++)
			{
				printf("0x%x.",buf[i]);
			}

			// send the packet
			write(fd, buf, size);
		}
	}
}

#endif // UNITTEST
//------------------------------------------------------------------------------
