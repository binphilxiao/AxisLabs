/**
 * \file
 * \author      Nabeel Ahmed
 * \brief	    Uart protocol encoder / decoder
 *
 * This program encodes the payload for packet_handler, 
 * or decodes payload from packet_handler.
 *
 * The structure of the payload is as follows:
 *
 \verbatim
 (primaryHeader) (secondaryHeader) (data) 
 \endverbatim
 *
 * \b (primaryHeader) and \b (secondaryHeader) are all one byte in size.
 * The data field can be up to 245 bytes in size. 
 *
 */

#ifndef __PROTOCOL_CODEC_H__
#define __PROTOCOL_CODEC_H__

#include <stdint.h>
#include <stdbool.h>

//#define MAX_DATA		245				///< max size of the data field

/// Gear info byte bit-masks (from advert packet of Gear)
#define GEAR_PWR_TYPE_MASK      0x03
#define GEAR_MACH_STATE_MASK    0x0C
#define GEAR_MACH_STATE_SHIFT   2
#define GEAR_POS_STATE_MASK     0x30
#define GEAR_POS_STATE_SHIFT    4

/// primaryHeader defenitions
typedef enum
{
    COMMAND_PROTO_GEARS  = 1,        ///< Commands for provisioned Gears
    COMMAND_PROTO_NETWORK,           ///< Commands for Bluetooth network management
    COMMAND_PROTO_UTILITY,           ///< Commands for various utilitarian purposes
} bridge_protocol_primary_headers_t;

/// secondaryHeader definitions

/// Command Protocol Gears - secondary Header
typedef enum
{
    SET_GEARS_POSITION    = 1,        ///< MT76-nRF Set position for gear or group of gears
    SET_GEAR_DFU_MODE,                ///< MT76-nRF Set specific Gear into BLE DFU mode
    GET_GEARS_POSITION,               ///< MT76-nRF Get the position for specified Gear
    GET_GEARS_BATTERY,                ///< MT76-nRF Get the battery level for sepcified Gear
    GET_GEARS_TEMPERATURE,            ///< MT76-nRF Get the temperature of specified Gear
    GET_GEARS_INFO,                   ///< MT76-nRF Get the info of specified Gear
    REPORT_GEAR_POSITION,             ///< nRF-MT76 Report the position of specified Gear
    REPORT_GEAR_BATTERY,              ///< nRF-MT76 Report the battery level of specified Gear
    REPORT_GEAR_TEMPERATURE,          ///< nRF-MT76 Report the temperature of specified Gear
    REPORT_GEAR_INFO,                 ///< nRF-MT76 Report the info of the speified Gear
    REPORT_NO_FEEDBACK,               ///< nRF-MT76 Report no feedback received from Gear
    REPORT_DFU_TARG_READY,            ///< nRF-MT76 Report DFU Target is now connected & ready
    WRITE_DFU_CNTRL_CMD,              ///< MT76-nRF Write DFU control point command
    WRITE_DFU_PCKT_DATA,              ///< MT76-nRF Write DFU packet data
    REPORT_DFU_NOTIF_DATA,            ///< nRF-MT76 Report received notification data from DFU target
    SET_BLE_DFU_COMPLETE,             ///< MT76-nRF Report end of DFU process.
    REPORT_GEAR_NAME,                 ///< nRF-MT76 Report Gear name.
    REPORT_GEAR_FW_VERSION,           ///< nRF-MT76 Report Gear Firmware Version.
    REPORT_GEAR_HW_VERSION,           ///< nRF-MT76 Report Gear Hardwarwe Version.
    REPORT_GEAR_PWR_TYPE,             ///< nRF-MT76 Report Gear Power Type 
    REPORT_GEAR_MACH_STATE,           ///< nRF-MT76 Report Gear Machine State
    REPORT_GEAR_POSITION_STATE,       ///< nRF-MT76 Report Gear Postion State
    SET_GEAR_NAME,                    ///< MT76-nRF Set Name of this Gear  

} cmd_proto_gears_secondary_header_t;


/// Command Protocol Network - Secondary Headers
typedef enum
{
    SET_PROVISION_MODE    = 1,        ///< MT76-nRF Set the bridge nRF to provisioning mode - scan all devices with name AXIS Gear V2
    GET_PROVISIONED_GEARS,            ///< MT76-nRF Get a list of provisioned Gear
    GET_ONLINE_GEARS,                 ///< MT76-nRF Get a list of Gears online (previously provisioned)
    DELETE_PROVISIONED_GEAR,          ///< MT76-nRF Delete a specific Gear - delete bonding information specified Gear
    CONNECT_SPECIFIED_GEAR,           ///< MT76-nRF Connect to a specific Gear and do nothing
    DISCONNECT_ALL,                   ///< MT76-nRF Disconnect from all connected Gears
    REPORT_SCANNED_GEAR,              ///< nRF-MT76 Report adress of Gear found while scanning during provisioning mode
    REPORT_GEAR_NOT_FOUND,            ///< nRF-MT76 Report Gear not found during normal network scanning
    REPORT_PROVISIONED_GEARS,         ///< nRF-MT76 Report a list of all currently provisioned Gears 
    REPORT_CONNECT_PROV_SUCCESS,      ///< nRF-MT76 Report successful provisioning to Gear of specified BLE Address
    REPORT_ONLINE_GEARS,              ///< nRF-MT76 Report list of provisioned Gears that are online
    REPORT_DELETE_SUCCESS,            ///< nRF-MT76 Report successfully deleted specified Gear/Peer (with address).
    REPORT_DELETE_ERROR,              ///< nRF-MT76 Report bond delete error/failed due for any reason.
    
} cmd_proto_network_secondary_header_t;

/// Command Protocol Utility - Secondary Header
typedef enum
{
    SET_GEAR_FACTORY_RESET = 1,       ///< MT76-nRF Facory Reset Gear. Delete all information from flash.
    SET_GEAR_DELETE_BOND,             ///< nRF-Gear Delete bond of specified peer device.
    SET_GEAR_BRIDGED_MODE,            ///< nRF-Gear Set Gear to bridge mode. Does not allow any other Central or Pair Mode untril factory reset.
    SET_NRF_SERIAL_DFU,               ///< MT76-nRF Set Bridge nRF to UART DFU mode - will causes system reset. 
    REPORT_BRIDGE_BUSY,               ///< nRF-MT76 Report nRF is busy with a process. Wait before requesting new command process.
    REPORT_FDBK_CSUM_ERR,             ///< nRF-MT76 Report checksum error from protocol decoder.
    REPORT_FDBK_SIZE_ERR,             ///< nRF-MT76 Report payload size error from protocol decoder.

} cmd_proto_utility_secondary_header_t;

/// tx packet object
typedef struct
{
  uint8_t data_size;

  bridge_protocol_primary_headers_t       primary_header;

  union
  {
    struct
    {
        uint8_t secondary_header;
    } value;
    struct
    {
      cmd_proto_gears_secondary_header_t    gear_header;
      cmd_proto_network_secondary_header_t  network_header; // not used in BLE communication to Gears
      cmd_proto_utility_secondary_header_t  utility_header;
    }header_type;
  } secondary_headers; 

  uint8_t * p_payload;

} tx_packet_obj_t;

/// Position Process SM state enumerations.
typedef enum
{
    SETUP_ADDR_FILTER,
    CHECK_CONNECTED,
    SEND_POSITION,
    AWAIT_FEEDBACK,
    FEEDBACK_TO_MT76,
    WAIT_STATE,
    SETUP_RECONNECT_ADDR,
    CHECK_RECONNECTED,
    DISCONNECT, 
} position_command_process_sm_t;

/// Provision Process SM state enumerations.
typedef enum
{
    SETUP_SCAN_FILTER,
    CHECK_PROVISIONED_CONNECTED, 
    SET_BRIDGED_MODE,
    REPORT_TO_MT76, 
    WAIT_FOR_INFO,
    COMPLETE,
    REPORT_ERROR,
} provision_process_sm_t;

/// Bond Delete Process SM state enumerations.
typedef enum
{
    SETUP_DEVICE_FILTER,
    CHECK_CONNECTION,
    SEND_DELETE_REQUEST,
    CHECK_DISCONNECTED,
    DELETE_PEER_BOND,
    CONFIRM_TO_MT76,
    DELETE_COMPLETE,
    DELETE_ERROR,

} bond_delete_process_sm_t; 

/// Set Gear Name Process SM state enumerations.
typedef enum
{
    CREATE_SCAN_FILTER, 
    VERIFY_CONNECTED,
    SEND_GEAR_NAME,
    WAIT_FOR_NAME,
    COMPLETE_NAMING,
} set_gear_name_process_sm_t;

/// Get Gear Temperature SM state enumerations.
typedef enum
{
  CREATE_TARGET_FILTER,
  VERIFY_TARGET_CONNECTED,
  SEND_GET_TEMP_CMD,
  WAIT_FOR_TEMP,
  COMPLETE_TEMP,
} get_gear_temp_process_sm_t;

/// BLE DFU Process SM state enumerations.
typedef  enum
{
    SETUP_TARGET_FILTER,
    CHECK_TARGET_CONNECTED,
    SEND_DFU_COMMAND,
    CHECK_TARGET_DISCONNECTED,
    SETUP_DFU_FILTER,
    CHECK_DFU_CONNECTED,
    REPORT_READY_MT76,
    SET_DFU_MODE_ACTIVE,
    BLE_DFU_STATE_WAIT,
    SEND_CONTROL_CMD,
    SEND_PACKET_DATA,
    DFU_COMPLETE

} 
gear_ble_dfu_process_sm_t;

//// Gear data object 
typedef struct
{
    uint8_t gear_addr[6];
    uint8_t conn_handle;
    //uint16_t peer_id;
    uint8_t name_len;
    char    gear_name[20];
    uint8_t position;
    uint8_t battery;
    uint8_t rprt_pos;
    bool    ble_connected;
    bool    ble_secured;
    bool    ble_notif_en;
} gear_obj_t;

/// group-of-gears object
typedef struct
{
    uint8_t     grp_size;
    gear_obj_t  grp_gear_obj[8]; // 8 = NRF_SDH_BLE_CENTRAL_LINK_COUNT
} group_obj_t; 

/// scan data object
typedef struct
{
    uint8_t   ble_addr[6];
    uint16_t   peer_id;
    bool      device_found;
    uint8_t * manuf_data;
} scan_obj_t;

/// signal to timer processes from another process
/// such as receive decoders (UART or BLE)
extern uint8_t message_signal;

/// Packet decoding state machine
//void command_decoder(uint8_t *payload);
/// Packet encoder
//void command_encoder(void);

#endif // __PROTOCOL_CODEC_H__
