/**
 * Copyright (c) 2016 - 2018, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
/**@cond To Make Doxygen skip documentation generation for this file.
 * @{
 */

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

//#include "amt.h"
//#include "counter.h"

#include "sdk_config.h"
#include "nrf.h"
#include "ble.h"
#include "ble_gatt.h"
#include "ble_hci.h"
#include "nordic_common.h"
#include "nrf_gpio.h"
#include "ble_advdata.h"
#include "ble_srv_common.h"
#include "ble_db_discovery.h"
#include "ble_conn_state.h"
#include "nrf_sdh.h"
#include "nrf_sdh_ble.h"
#include "fds.h"
#include "peer_manager.h"
#include "app_timer.h"
#include "app_error.h"
#include "app_uart.h"
#include "nrf_ble_gatt.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_ble_qwr.h"
#include "nrf_ble_scan.h"
#include "nrf_uart.h"
#include "nrf_uarte.h"
#include "nrf_queue.h"
#include "nrf_drv_qspi.h"

#include "ble_cus_client.h"
#include "packet_handler.h"
#include "protocol_codec.h"
#include "ble_dfu_client.h"
#include "ble_link_list.h"
#include "pa_lna.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "nrf_power.h"
#include "nrf_bootloader.h"
#include "nrf_bootloader_info.h"
#include "nrf_svci_async_function.h"
#include "nrf_svci_async_handler.h"
#include "boards.h"
#include "led_softblink.h"
#include "nrf_delay.h"

#define CONN_INTERVAL_DEFAULT           (uint16_t)(MSEC_TO_UNITS(7.5, UNIT_1_25_MS))    /**< 7.5 Default connection interval used at connection establishment by central side. */
#define CONN_INTERVAL_DFU               (uint16_t)(MSEC_TO_UNITS(50, UNIT_1_25_MS))     /**< 50 DFU connection interval used at connection establishment by central side. */

#define CONN_INTERVAL_MIN               (uint16_t)(MSEC_TO_UNITS(7.5, UNIT_1_25_MS))    /**< 7.5 Minimum acceptable connection interval, in 1.25 ms units. */
#define CONN_INTERVAL_MAX               (uint16_t)(MSEC_TO_UNITS(500, UNIT_1_25_MS))    /**< 30 Maximum acceptable connection interval, in 1.25 ms units. */
#define CONN_SUP_TIMEOUT                (uint16_t)(MSEC_TO_UNITS(4000,  UNIT_10_MS))    /**< Connection supervisory timeout (4 seconds). */
#define SLAVE_LATENCY                   0                                               /**< Slave latency. */

#define SEC_PARAM_BOND                  1                                       /**< Perform bonding. */
#define SEC_PARAM_MITM                  0                                       /**< Man In The Middle protection not required. */
#define SEC_PARAM_LESC                  0                                       /**< LE Secure Connections not enabled. */
#define SEC_PARAM_KEYPRESS              0                                       /**< Keypress notifications not enabled. */
#define SEC_PARAM_IO_CAPABILITIES       BLE_GAP_IO_CAPS_NONE                    /**< No I/O capabilities. */
#define SEC_PARAM_OOB                   0                                       /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE          7                                       /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE          16                                      /**< Maximum encryption key size. */


#define FAST_BLINK_INTERVAL		APP_TIMER_TIKCS(200) 
APP_TIMER_DEF(m_scan_slow_blink_timer_id);                                      /**< Timer used to toggle LED for "scan mode" indication on the dev.kit. */                  

#define SLOW_BLINK_INTERVAL		APP_TIMER_TICKS(750)

#define PROCESS_SM_INTERVAL		APP_TIMER_TICKS(50)
APP_TIMER_DEF(m_position_command_timer_id);                                     /**< Timer to run the position command function state-machine */
APP_TIMER_DEF(m_provision_process_timer_id);                                    /**< Timer for provisioning process state-machine. */
APP_TIMER_DEF(m_bond_delete_process_timer_id);                                  /**< Timer for bond delete process state-machine. */
APP_TIMER_DEF(m_set_name_command_timer_id);                                     /**< Timer for set Gear name process state-machine. */
APP_TIMER_DEF(m_get_temperature_timer_id);                                      /**< Timer for get Gear temperature state-machine. */
      
#define PWM_WRITE_INTERVAL              APP_TIMER_TICKS(100) 
APP_TIMER_DEF(m_pwm_write_timer_id);                      

#define PROVISION_MODE_TIMEOUT          APP_TIMER_TICKS(30000)                  /**< 30 second timeout for provision mode expiry.*/
APP_TIMER_DEF(m_provisioning_mode_timer_id);                                    /**< Provisioning mode timer */

#define DATASCAN_MODE_TIMEOUT           APP_TIMER_TICKS(60000)                  /**< 1 min timeout for scan-response data send.*/
APP_TIMER_DEF(m_datascan_process_timer_id);                                     /**< Timer to run the once-a-min network scanning of Gears.*/  
                 
#define BLE_DFU_INTERVAL                APP_TIMER_TICKS(100)                    /**< 20ms timer for running the BLE DFU SM process */
APP_TIMER_DEF(m_ble_dfu_process_timer_id);                                      /**< timer for BLE DFU */

#define CMD_DQ_INTERVAL                 APP_TIMER_TICKS(20)                     /**< 20ms timer for command dequeue process. */
APP_TIMER_DEF(m_cmd_dq_process_timer_id);                                       /**< timer for command dequeue. */
                         
#define APP_BLE_CONN_CFG_TAG            1                                       /**< A tag that refers to the BLE stack configuration. */
#define APP_BLE_OBSERVER_PRIO           3                                       /**< Application's BLE observer priority. You shouldn't need to modify this value. */

#define UART_TX_BUF_SIZE                256                                     /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE                256                                     /**< UART RX buffer size. */

#define QSPI_STD_CMD_WRSR               0x01
#define QSPI_STD_CMD_RSTEN              0x66
#define QSPI_STD_CMD_RST                0x99

#define QSPI_DATA_SIZE                  128

#define ENABLE_RSSI
//#define APP_PA_LNA                                                              /**< Define to allow setup of PA_LNA if using a Fanstel BT840X nRF module. */
  
#ifdef APP_PA_LNA
#define APP_PA_PIN      17
#define APP_LNA_PIN     19
#define APP_CHL_PIN	8
#define APP_CPS_PIN	6
#endif


NRF_BLE_SCAN_DEF(m_scan_non_conn);                                              /**< scan module instance for scanning-only of bonded peers */
BLE_CUS_ARRAY_DEF(m_ble_cus_service_client, NRF_SDH_BLE_CENTRAL_LINK_COUNT);    /**< Main structure used by the CUS Service client module. */
BLE_DFU_DEF(m_ble_dfu_service_client);                                          /**< Main structure used by the DFU Service client module. */
BLE_DB_DISCOVERY_ARRAY_DEF(m_db_disc, NRF_SDH_BLE_CENTRAL_LINK_COUNT);          /**< DB discovery module instance. */ 
NRF_BLE_GATT_DEF(m_gatt);                                                       /**< GATT module instance. */


NRF_QUEUE_DEF(uint8_t, m_byte_queue, 256, NRF_QUEUE_MODE_NO_OVERFLOW);
NRF_QUEUE_INTERFACE_DEC(uint8_t, byte_queue);
NRF_QUEUE_INTERFACE_DEF(uint8_t, byte_queue, &m_byte_queue)


static uint8_t m_adv_handle = BLE_GAP_ADV_SET_HANDLE_NOT_SET;                   /**< Advertising handle used to identify an advertising set. */
static uint8_t m_enc_advdata[BLE_GAP_ADV_SET_DATA_SIZE_MAX];                    /**< Buffer for storing an encoded advertising set. */
static uint8_t m_enc_scandata[BLE_GAP_SCAN_BUFFER_EXTENDED_MIN];                /**< Buffer for storing an encoded advertising set. */

static gear_obj_t gear_obj/*[NRF_SDH_BLE_CENTRAL_LINK_COUNT]*/;
static scan_obj_t scan_obj/*[NRF_SDH_BLE_CENTRAL_LINK_COUNT]*/;
static group_obj_t grp_obj;

void scan_filter_of_bonded_peers(void);
void scan_filter_increment_peer(bool reset);

static void position_command_process_sm(group_obj_t * p_grp_obj, position_command_process_sm_t m_state);
static void provision_process_sm(gear_obj_t * p_gear_obj);
static void bond_delete_process_sm(gear_obj_t * p_gear_obj);
static void gear_ble_dfu_process_sm(gear_obj_t * p_gear_obj, gear_ble_dfu_process_sm_t m_state);
static void set_gear_name_process_sm(gear_obj_t * p_gear_obj);
static void get_gear_temp_process_sm(gear_obj_t * p_gear_obj);

void ble_packet_processor(tx_packet_obj_t * p_tx_packet_obj, uint8_t link_count);
void tx_packet_processor(tx_packet_obj_t * p_tx_packet_obj);
static void notif_packet_processor(uint8_t const * p_payload, uint8_t length);

void payload_dequeue(void);
static void report_device_busy(void);


/// QSPI declerations
#define WAIT_FOR_PERIPH() do { \
        while (!m_finished) {} \
        m_finished = false;    \
    } while (0)

static volatile bool m_finished = false;
static uint8_t m_buffer_tx[QSPI_DATA_SIZE];
static uint8_t m_buffer_rx[QSPI_DATA_SIZE];

extern ble_dfu_mode_t m_dfu_mode;                                               /**< Global variable holding BLE DFU Mode */

typedef enum                                                                    /**< Type holding the scan selection modes.*/
{
    SELECTION_SCAN_NON_CONN = 0,  // Scanning, not trying to connect.
    SELECTION_SCAN_CONN,          // Scanning, trying to connect when target name/address matches.
    SELECTION_SCAN_PROVISIONING,  // Scanning, provisioning mode. Looking for AXIS Gear V2 BLE devices.
    SELECTION_SCAN_PAUSED,        // Pause Scanning, used in specific circumstances where scanning not desired.
} scan_type_seclection_t;
static scan_type_seclection_t    m_scan_type_selected    = SELECTION_SCAN_NON_CONN;
static void scan_selection_state_set(scan_type_seclection_t scan_selection);

static bool    m_app_initiated_disconnect   = false;                            /**<The application has initiated disconnect. Used to "tell" on_ble_gap_evt_disconnected() to not start scanning. */
static bool    m_waiting_for_disconnect_evt = false;                            /**< Disconnect is initiated. The application has to wait for BLE_GAP_EVT_DISCONNECTED before proceeding. */

static bool    m_bridge_busy  = false;                                          /**< Bridge is busy with some process, cannot start new requested process until free. */

static uint16_t m_conn_handle = BLE_CONN_HANDLE_INVALID;                        /**< Handle of the current BLE connection .*/
static uint8_t m_gap_role     = BLE_GAP_ROLE_INVALID;                           /**< BLE role for this connection, see @ref BLE_GAP_ROLES */

/// Name to use for advertising and connection.
#define DEVICE_NAME "GRV2"//"AXIS Gear V2"
static char const m_target_periph_name[] = DEVICE_NAME;                         /**< Name of the device we try to connect to. This name is searched in the scan report data*/

uint8_t message_signal = 0;                                                     /**< Signal to timer processes from another process such as receive decoders (UART or BLE) */  

static ble_gap_scan_params_t const m_scan_param/*_1MBps*/ =
{
    .active        = 0x01,
    .interval      = NRF_BLE_SCAN_SCAN_INTERVAL,
    .window        = NRF_BLE_SCAN_SCAN_WINDOW,
    .timeout       = 0x0000, // No timeout.
    .scan_phys     = BLE_GAP_PHY_1MBPS,
    .filter_policy = BLE_GAP_SCAN_FP_ACCEPT_ALL,
};

/// Connection parameters requested for connection.
static ble_gap_conn_params_t m_conn_param =
{
    .min_conn_interval = CONN_INTERVAL_MIN,   // Minimum connection interval.
    .max_conn_interval = CONN_INTERVAL_MAX,   // Maximum connection interval.
    .slave_latency     = SLAVE_LATENCY,       // Slave latency.
    .conn_sup_timeout  = CONN_SUP_TIMEOUT     // Supervisory timeout.
};

static void check_scan_result(void)
{

    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];

    if (/*scan_obj.peer_id != 0 && */scan_obj.device_found == false)
    {
        NRF_LOG_INFO("GEAR NOT FOUND");
        tx_packet_obj.data_size = 6;
        tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
        tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
        memcpy(&tx_payload, scan_obj.ble_addr, 6);
        tx_packet_obj.p_payload = tx_payload; 

        tx_packet_processor(&tx_packet_obj);
    }
}

/// Timeout Handler for scanning-mode LED blink.
static void scan_slow_blink_timeout_handler(void * p_context)
{

}

/// Timeout Handler for position command process state-machine.
static void position_command_timeout_handler(void * p_context)
{
        position_command_process_sm(&grp_obj, NULL);
}

/// Timeout Handler for timeout of provisioning mode.
void provisioning_mode_timeout_handler(void * p_context)
{
        //scan_filter_of_bonded_peers();
        m_bridge_busy  = false;  
        app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);
}

/// Timeout Handler for the provision mode state-machine.
void provision_process_timeout_handler(void * p_context)
{
        provision_process_sm(&gear_obj);
}

/// Timeout Handler for the datascan every min of network Gears.
void datascan_process_timeout_handler(void * p_context)
{       
            
        check_scan_result();
        scan_filter_increment_peer(false);
}
/// Timeout handler for delete process.
void bond_delete_process_timeout_handler(void * p_context)
{
        bond_delete_process_sm(&gear_obj);
}
/// Timeout process for DFU process.
void ble_dfu_process_timeout_handler(void * p_context)
{
        gear_ble_dfu_process_sm(&gear_obj, NULL);
}
/// Timeout process for dequeue of commands payloads. 
void cmd_dq_process_timeout_handler(void * p_context)
{
        payload_dequeue();
}
/// Timeout process for bond delete process.
void set_name_command_timeout_handler(void * p_context)
{
        set_gear_name_process_sm(&gear_obj);
}
/// Timeouot process for Gear temperature
void get_temperature_process_timeout_handler(void * p_context)
{
        get_gear_temp_process_sm(&gear_obj);
}

void write_pwm_peer(void)
{
//    ret_code_t err_code;
//    static uint8_t pwm = 0;
//    static int count = 0;
//
//    switch(count)
//    {
//      case 0:
//      {
//        pwm+=10;
//        err_code = ble_cus_service_cus_command_send(&m_ble_cus_service_client, pwm);
//        if(pwm == 100) {count = 1;}
//      } break;
//
//      case 1:
//      {
//        pwm-=10;
//        err_code = ble_cus_service_cus_command_send(&m_ble_cus_service_client, pwm);
//        if(pwm == 0) 
//        {
//          count = 0;
//          app_timer_stop(m_pwm_write_timer_id);
//        }
//      } break;
//
//      default:
//        break;
//    }
}

static void pwm_write_timeout_handler(void * p_context)
{
    write_pwm_peer();
}


/**@brief Function to start scanning.
 * Scanning is started based on the internal parameters (global variables) set.
 */
static void scan_start(void) 
{
   ret_code_t err_code;

    //NRF_LOG_INFO("Disconnect before scan...");
    //err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
    //APP_ERROR_CHECK(err_code);

    err_code = sd_ble_gap_tx_power_set(BLE_GAP_TX_POWER_ROLE_SCAN_INIT, m_adv_handle, 8);
                APP_ERROR_CHECK(err_code);

    NRF_LOG_INFO("Start Scan");
    err_code = nrf_ble_scan_start(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

}

/**@brief Function for enabling reception of RSSI values when in a connection. 
 */
static void rssi_measurements_start(void)
{
  uint8_t threshold    = 2;
  uint8_t skip_count   = 10;
  ret_code_t err_code = sd_ble_gap_rssi_start(m_conn_handle, threshold, skip_count);
                         APP_ERROR_CHECK(err_code);

}

/**@brief Function for handling BLE_GAP_ADV_REPORT events.
 * Log adv report upon device name match or if "non-connectable" advertising on coded phy is received.
 * If in state "scanning, trying to connect", send connection request to device with matching device name.
 */
static void on_adv_report(ble_gap_evt_adv_report_t const * p_adv_report)
{
    static int8_t   rssi_value = 0;
    ret_code_t err_code;
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];
    uint16_t offset = 0;
    uint16_t data;
    static uint8_t ble_addr[6];

    if(m_scan_type_selected == SELECTION_SCAN_PROVISIONING)
    {
        bool adv_target_name_found = ble_advdata_name_find(p_adv_report->data.p_data,
                                        p_adv_report->data.len,
                                        m_target_periph_name);

        if (adv_target_name_found && p_adv_report->type.scan_response == 1)
        {
          data = ble_advdata_search(p_adv_report->data.p_data, p_adv_report->data.len, &offset, 0xFF); //Manufacturer Specfic Data Ad Type = 0xFF
          if ( ((p_adv_report->data.p_data[offset+2]&0x40)>>6) == 0x01 && p_adv_report->data.p_data[offset] == 0x09 
                                                                       && p_adv_report->data.p_data[offset+1] == 0x04)
          {
            NRF_LOG_INFO("Pair Mode Gear Found!");
            tx_packet_obj.data_size = 6;
            tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_SCANNED_GEAR;
            memcpy(&tx_payload, p_adv_report->peer_addr.addr, 6);
            tx_packet_obj.p_payload = tx_payload; 

            tx_packet_processor(&tx_packet_obj);
            
            memcpy(gear_obj.gear_addr, p_adv_report->peer_addr.addr, 6);
            // Initiate connection.
//            m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
//            m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT;
//
//            NRF_LOG_INFO("Connecting...");
//
//            err_code = sd_ble_gap_connect(&p_adv_report->peer_addr,
//                                          &m_scan_param,
//                                          &m_conn_param,
//                                          APP_BLE_CONN_CFG_TAG); 

            scan_selection_state_set(SELECTION_SCAN_PAUSED); //found, so no need to keep reporting same found GearV2
            app_timer_start(m_provision_process_timer_id, PROCESS_SM_INTERVAL, NULL);
          }
        }

    }

    if(m_scan_type_selected == SELECTION_SCAN_NON_CONN) // only if in scanning-only mode (not trying to connect)
    {
        #ifdef ENABLE_RSSI
        if(rssi_value != p_adv_report->rssi)
        {
            rssi_value = p_adv_report->rssi;
            NRF_LOG_INFO("Received ADV report, RSSI: %d", rssi_value);
        }
        #endif

        //NRF_LOG_INFO("Scan Match!");
        if (p_adv_report->type.scan_response == 1)
        {
          data = ble_advdata_search(p_adv_report->data.p_data, p_adv_report->data.len, &offset, 0xFF); //Manufacturer Specfic Data Ad Type = 0xFF
          if (p_adv_report->data.p_data[offset] == 0x09 && p_adv_report->data.p_data[offset+1] == 0x04) //BLE Company Identifier 0409
          {
            nrf_ble_scan_stop(); // Stop until next filter set for scan
            NRF_LOG_INFO("Scan Result - Gear Info: %x, Position: %d, Battery: %d",p_adv_report->data.p_data[offset+2], p_adv_report->data.p_data[offset+3], p_adv_report->data.p_data[offset+4]); 
            scan_obj.device_found = true;
            // send report to MT76
            tx_packet_obj.data_size = 8;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_BATTERY;
            tx_payload[0] = p_adv_report->data.p_data[offset+4];
            tx_payload[1] = (p_adv_report->data.p_data[offset+2] & GEAR_PWR_TYPE_MASK);
            memcpy(&tx_payload[2], p_adv_report->peer_addr.addr, 6);
            tx_packet_obj.p_payload = tx_payload; 
            tx_packet_processor(&tx_packet_obj);
            // send report to MT76
            tx_packet_obj.data_size = 8;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_POSITION;
            tx_payload[0] = p_adv_report->data.p_data[offset+3];
            tx_payload[1] = (p_adv_report->data.p_data[offset+2] & GEAR_POS_STATE_MASK) >> GEAR_POS_STATE_SHIFT;
            memcpy(&tx_payload[2], p_adv_report->peer_addr.addr, 6);
            tx_packet_obj.p_payload = tx_payload; 
            tx_packet_processor(&tx_packet_obj);
            // send report to MT76
//            tx_packet_obj.data_size = 7;
//            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
//            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_INFO;
//            tx_payload[0] = p_adv_report->data.p_data[offset+2];
//            memcpy(&tx_payload[1], p_adv_report->peer_addr.addr, 6);
//            tx_packet_obj.p_payload = tx_payload; 
//            tx_packet_processor(&tx_packet_obj);
            // Report power type
//            tx_packet_obj.data_size = 7;
//            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
//            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_PWR_TYPE;
//            tx_payload[0] = (p_adv_report->data.p_data[offset+2] & GEAR_PWR_TYPE_MASK);
//            memcpy(&tx_payload[1], p_adv_report->peer_addr.addr, 6);
//            tx_packet_obj.p_payload = tx_payload; 
//            tx_packet_processor(&tx_packet_obj);
            // Report machine state
            tx_packet_obj.data_size = 7;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_MACH_STATE;
            tx_payload[0] = (p_adv_report->data.p_data[offset+2] & GEAR_MACH_STATE_MASK) >> GEAR_MACH_STATE_SHIFT;
            memcpy(&tx_payload[1], p_adv_report->peer_addr.addr, 6);
            tx_packet_obj.p_payload = tx_payload; 
            tx_packet_processor(&tx_packet_obj);
            // Report position state
//            tx_packet_obj.data_size = 7;
//            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
//            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_POSITION_STATE;
//            tx_payload[0] = (p_adv_report->data.p_data[offset+2] & GEAR_POS_STATE_MASK) >> GEAR_POS_STATE_SHIFT;
//            memcpy(&tx_payload[1], p_adv_report->peer_addr.addr, 6);
//            tx_packet_obj.p_payload = tx_payload; 
//            tx_packet_processor(&tx_packet_obj);
          }
        }
    }
 
    if (m_scan_type_selected == SELECTION_SCAN_CONN)
    {
        #ifdef ENABLE_RSSI
        if(rssi_value != p_adv_report->rssi)
        {
            rssi_value = p_adv_report->rssi;
            NRF_LOG_INFO("Received ADV report, RSSI: %d", rssi_value);
        }
        #endif
        if(memcmp(p_adv_report->peer_addr.addr, gear_obj.gear_addr, 6) == 0)
        {
            // Initiate connection. CHANGE: will use init values, or use DFU-specific for DFU process.
            //m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
            //m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT;

            NRF_LOG_INFO("Connecting...");

            err_code = sd_ble_gap_connect(&p_adv_report->peer_addr,
                                          &m_scan_param,
                                          &m_conn_param,
                                          APP_BLE_CONN_CFG_TAG);    

            if (err_code != NRF_SUCCESS)
            {
               NRF_LOG_ERROR("sd_ble_gap_connect() failed: 0x%x.", err_code);
               scan_start();
            }
        }
    }
//    if(m_scan_type_selected == SELECTION_SCAN_CONN)
//    { 
//        // Connect if the received adv_report has the set target "DEVICE_NAME" (sdk_config.h)
//         if (!ble_advdata_name_find(p_adv_report->data.p_data,
//                                    p_adv_report->data.len,
//                                    m_target_periph_name))
//         {
//             scan_start();
//         }
//         
//         NRF_LOG_INFO("Device \"%s\" found, sending a connection request.",
//                      (uint32_t) m_target_periph_name);
//         
//         // Initiate connection.
//         m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
//         m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT;
//         
//         NRF_LOG_INFO("Connecting on 1Mbps.");
//       
//         err_code = sd_ble_gap_connect(&p_adv_report->peer_addr,
//                                        &m_scan_param,
//                                        &m_conn_param,
//                                        APP_BLE_CONN_CFG_TAG);    
//            
//         if (err_code != NRF_SUCCESS)
//         {
//             NRF_LOG_ERROR("sd_ble_gap_connect() failed: 0x%x.", err_code);
//             scan_start();
//         }
//    }

}


/**@brief Function for handling BLE_GAP_EVT_CONNECTED events.
 * Save the connection handle and GAP role. 
 * Start RSSI measurements and turn on the LED associated with the "connected state".
 */
static void on_ble_gap_evt_connected(ble_gap_evt_t const * p_gap_evt)
{
    ret_code_t err_code;
    
    m_conn_handle = p_gap_evt->conn_handle;
    m_gap_role    = p_gap_evt->params.connected.role;

    err_code = sd_ble_gap_tx_power_set(BLE_GAP_TX_POWER_ROLE_CONN, m_conn_handle, 8);
                APP_ERROR_CHECK(err_code);
    
    if (m_gap_role == BLE_GAP_ROLE_CENTRAL)
    {
        NRF_LOG_INFO("Connected as a central.");
    }

    if ( memcmp(p_gap_evt->params.connected.peer_addr.addr, gear_obj.gear_addr, 6) == 0)
    {
        gear_obj.ble_connected = true;
        gear_obj.conn_handle = p_gap_evt->conn_handle;
    }
    
    // Stop scanning.
    nrf_ble_scan_stop();

    //rssi_measurements_start();
}


/**@brief Function for handling BLE_GAP_EVT_DISCONNECTED events.
 * Unset the connection handle and restart scanning if needed.
 */
static void on_ble_gap_evt_disconnected(ble_gap_evt_t const * p_gap_evt)
{
    m_conn_handle = BLE_CONN_HANDLE_INVALID;
    m_waiting_for_disconnect_evt = false;

    gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;
    gear_obj.conn_handle = p_gap_evt->conn_handle;

    NRF_LOG_DEBUG("Disconnected: reason 0x%x.", p_gap_evt->params.disconnected.reason); 
    //https://infocenter.nordicsemi.com/index.jsp?topic=%2Fcom.nordic.infocenter.s132.api.v2.0.0%2Fgroup___b_l_e___h_c_i___s_t_a_t_u_s___c_o_d_e_s.html

    
    if(m_app_initiated_disconnect == false && m_scan_type_selected != SELECTION_SCAN_PAUSED)  // (If a the app itself (button push) has initiated a disconnect, bsp_evt_handler will start the scanning.)
    {
      scan_start();
    }

}

/**@brief Function for handling BLE events left over from ble_evt_handler.
 *
 * @param[in] p_ble_evt->header.evt_id  Bluetooth stack event id.
 */
static void ble_gattc_sub_evt_handler(uint16_t evt)
{
    switch (evt)
    {
      case BLE_GATTC_EVT_CHAR_DISC_RSP:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_CHAR_DISC_RSP");
      } break;
      case BLE_GATTC_EVT_READ_RSP:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_READ_RSP");
      } break;
      case BLE_GATTC_EVT_WRITE_RSP:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_WRITE_RSP");
      } break;
      case BLE_GATTC_EVT_HVX:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_HVX");
      } break;
      case BLE_GATTC_EVT_EXCHANGE_MTU_RSP:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_EXCHANGE_MTU_RSP");
      } break;
      case BLE_GATTC_EVT_TIMEOUT:
      {
          NRF_LOG_INFO("BLE_GATTC_EVT_TIMEOUT");
      } break;
      case BLE_GATTC_EVT_WRITE_CMD_TX_COMPLETE:
      {
          //NRF_LOG_INFO("BLE_GATTC_EVT_WRITE_CMD_TX_COMPLETE");
      } break;
      default:
        {
          NRF_LOG_DEBUG("Received an unimplemented BLE event. %x", evt);
        } break;
    }
}

/**@brief Function for handling BLE Stack events.
 *
 * @param[in] p_ble_evt  Bluetooth stack event.
 */
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    static int8_t              rssi_value = 0;
    uint8_t                    channel_rssi;
    uint32_t                   err_code;
    ble_gap_evt_t const * p_gap_evt = &p_ble_evt->evt.gap_evt;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_ADV_REPORT:
            //on_adv_report(&p_gap_evt->params.adv_report);
            break;         

        case BLE_GAP_EVT_CONNECTED:
        {
            on_ble_gap_evt_connected(p_gap_evt);

            NRF_LOG_INFO("Connection 0x%x established, starting DB discovery.",
                         p_gap_evt->conn_handle);
            APP_ERROR_CHECK_BOOL(p_gap_evt->conn_handle < NRF_SDH_BLE_CENTRAL_LINK_COUNT);
            // Discover peer's Services
            // handle assign happens in BLE_CUS_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE event handler
//            err_code = ble_cus_service_client_handles_assign(&m_ble_cus_service_client[p_gap_evt->conn_handle], 
//                                                              p_gap_evt->conn_handle, NULL);
//                        APP_ERROR_CHECK(err_code);

            err_code = ble_db_discovery_start(&m_db_disc[p_gap_evt->conn_handle], 
                                              p_gap_evt->conn_handle);
                        APP_ERROR_CHECK(err_code);
        }   break;
            
        
        case BLE_GAP_EVT_DISCONNECTED:
            on_ble_gap_evt_disconnected(p_gap_evt);
            break;
        
        case BLE_GAP_EVT_CONN_PARAM_UPDATE:
        {
            
            NRF_LOG_INFO("Connection interval updated: 0x%x, 0x%x.",
                p_gap_evt->params.conn_param_update.conn_params.min_conn_interval,
                p_gap_evt->params.conn_param_update.conn_params.max_conn_interval);
        } break;
        
        case BLE_GAP_EVT_CONN_PARAM_UPDATE_REQUEST:
        {
            // Accept parameters requested by the peer.
            ble_gap_conn_params_t params;
            params = p_gap_evt->params.conn_param_update_request.conn_params;
            err_code = sd_ble_gap_conn_param_update(p_gap_evt->conn_handle, &params);
                        APP_ERROR_CHECK(err_code);
        
            NRF_LOG_INFO("Connection interval updated (upon request): 0x%x, 0x%x.",
                p_gap_evt->params.conn_param_update_request.conn_params.min_conn_interval,
                p_gap_evt->params.conn_param_update_request.conn_params.max_conn_interval);
        } break;

       case BLE_GAP_EVT_RSSI_CHANGED:
       {
         rssi_value =  p_gap_evt->params.rssi_changed.rssi;
         channel_rssi =  p_gap_evt->params.rssi_changed.ch_index;
         NRF_LOG_INFO("RSSI changed, new: %d, channel: %d",rssi_value, channel_rssi); 
       } break;

       case BLE_GATTC_EVT_TIMEOUT: // Fallthrough.
       case BLE_GATTS_EVT_TIMEOUT:
       {
           NRF_LOG_DEBUG("GATT timeout, disconnecting.");
           err_code = sd_ble_gap_disconnect(m_conn_handle,
                                            BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                        APP_ERROR_CHECK(err_code);
       } break;
        
        case BLE_GAP_EVT_PHY_UPDATE:
        {
           NRF_LOG_INFO("BLE_GAP_EVT_PHY_UPDATE: not implemented");
        } break;
        
        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:
        {
           NRF_LOG_INFO("BLE_GAP_EVT_PHY_UPDATE_REQUEST: not implemented");

        } break;

        default:
        {
          //NRF_LOG_DEBUG("Received an unimplemented BLE event. %x", p_ble_evt->header.evt_id);
            // No implementation needed.
            ble_gattc_sub_evt_handler(p_ble_evt->header.evt_id);
        } break;
    }
}

/**@brief GATT module event handler.
 */
static void gatt_evt_handler(nrf_ble_gatt_t * p_gatt, nrf_ble_gatt_evt_t const * p_evt)
{
    switch (p_evt->evt_id)
    {
        case NRF_BLE_GATT_EVT_ATT_MTU_UPDATED:
        {
            NRF_LOG_INFO("GATT ATT MTU on connection 0x%x changed to %d.",
                         p_evt->conn_handle,
                         p_evt->params.att_mtu_effective);
        } break;

        case NRF_BLE_GATT_EVT_DATA_LENGTH_UPDATED:
        {
            NRF_LOG_INFO("Data length for connection 0x%x updated to %d.",
                         p_evt->conn_handle,
                         p_evt->params.data_length);
        } break;

        default:
            break;
    }
}


/**@brief Function for handling Scaning events.
 *
 * @param[in]   p_scan_evt   Scanning event.
 */
static void scan_evt_handler(scan_evt_t const * p_scan_evt)
{
    ret_code_t err_code;

    switch(p_scan_evt->scan_evt_id)
    {
        case NRF_BLE_SCAN_EVT_FILTER_MATCH:
            on_adv_report(p_scan_evt->params.filter_match.p_adv_report);
            break;

        case NRF_BLE_SCAN_EVT_CONNECTING_ERROR:
            err_code = p_scan_evt->params.connecting_err.err_code;
                        APP_ERROR_CHECK(err_code);
            break;
        default:
          break;
    }
}

/**@brief Function for initializing the log module.
 */
static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(app_timer_cnt_get);
                            APP_ERROR_CHECK(err_code);
	
    NRF_LOG_DEFAULT_BACKENDS_INIT();
}



/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates application timers.
 */
static void timer_init(void)
{
  ret_code_t err_code = app_timer_init();
              APP_ERROR_CHECK(err_code);

  // Creating the timers used to indicate the state/selection mode of the board.
  err_code = app_timer_create(&m_scan_slow_blink_timer_id, APP_TIMER_MODE_REPEATED, scan_slow_blink_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for writing PWM value to peer.
  err_code = app_timer_create(&m_pwm_write_timer_id, APP_TIMER_MODE_REPEATED, pwm_write_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer to run function to manage position control of peer Gears when reciving position command from MT76 .
  err_code = app_timer_create(&m_position_command_timer_id, APP_TIMER_MODE_REPEATED, position_command_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for Provisioning procedure 1 min.
  err_code = app_timer_create(&m_provisioning_mode_timer_id, APP_TIMER_MODE_SINGLE_SHOT, provisioning_mode_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for provisioning specified Gear. 
  err_code = app_timer_create(&m_provision_process_timer_id, APP_TIMER_MODE_REPEATED, provision_process_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for scan_response data collection and sent to MT76
  err_code = app_timer_create(&m_datascan_process_timer_id, APP_TIMER_MODE_REPEATED, datascan_process_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for gear/peer bond delete process
  err_code = app_timer_create(&m_bond_delete_process_timer_id, APP_TIMER_MODE_REPEATED, bond_delete_process_timeout_handler);
              APP_ERROR_CHECK(err_code);
  
  // Timer for Gear BLE DFU process
  err_code = app_timer_create(&m_ble_dfu_process_timer_id, APP_TIMER_MODE_REPEATED, ble_dfu_process_timeout_handler);
              APP_ERROR_CHECK(err_code);

  // Timer for command queue dequeue process.
  err_code = app_timer_create(&m_cmd_dq_process_timer_id, APP_TIMER_MODE_REPEATED, cmd_dq_process_timeout_handler);
              APP_ERROR_CHECK(err_code);
  
  // Timer for set gear name process.
  err_code = app_timer_create(&m_set_name_command_timer_id, APP_TIMER_MODE_REPEATED, set_name_command_timeout_handler);
              APP_ERROR_CHECK(err_code);              
  
  // Timer for get gear temperature process.
  err_code = app_timer_create(&m_get_temperature_timer_id, APP_TIMER_MODE_REPEATED, get_temperature_process_timeout_handler);
              APP_ERROR_CHECK(err_code);  
}


/**@brief Function for initializing the BLE stack.
 *
 * @details Initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void)
{
    ret_code_t err_code;

    err_code = nrf_sdh_enable_request();
                APP_ERROR_CHECK(err_code);

    // Configure the BLE stack using the default settings.
    // Fetch the start address of the application RAM.
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
                APP_ERROR_CHECK(err_code);

//    ble_cfg_t ble_cfg;
//    memset(&ble_cfg, 0, sizeof(ble_cfg));
//    ble_cfg.conn_cfg.conn_cfg_tag = BLE_CONN_CFG_GATTC;
//    ble_cfg.conn_cfg.params.gattc_conn_cfg.write_cmd_tx_queue_size = 20;
//    err_code = sd_ble_cfg_set(BLE_CONN_CFG_GATTC, &ble_cfg, ram_start);
//                APP_ERROR_CHECK(err_code);

    // Enable BLE stack.
    err_code = nrf_sdh_ble_enable(&ram_start);
                APP_ERROR_CHECK(err_code);

    // Register a handler for BLE events.
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}


/**@brief Function for initializing GAP parameters.
 *
 * @details This function sets up all the necessary GAP (Generic Access Profile) parameters of the
 *          device including the device name and the preferred connection parameters.
 */
static void gap_params_init(void)
{
    ret_code_t              err_code;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (uint8_t const *)DEVICE_NAME,
                                          strlen(DEVICE_NAME));
                APP_ERROR_CHECK(err_code);

    err_code = sd_ble_gap_ppcp_set(&m_conn_param);
                APP_ERROR_CHECK(err_code);
}



/**@brief Function for initializing power management.
 */
static void power_management_init(void)
{
    ret_code_t ret;
    ret = nrf_pwr_mgmt_init();
            APP_ERROR_CHECK(ret);
}


/**@brief Function for handling the idle state (main loop).
 *
 * @details Handle any pending operation(s), then sleep until the next event occurs.
 */
static void idle_state_handle(void)
{
    if (NRF_LOG_PROCESS() == false)
    {
       // nrf_pwr_mgmt_run();
    }
}


/**@brief Function setting the internal scan state.
 * Note: this function sets the internal "scan selection state", it does not start scanning.
 *       The new scan mode will be used when (re-)starting to scan.
 */
static void scan_selection_state_set(scan_type_seclection_t scan_selection)
{
 ret_code_t err_code;

  m_scan_type_selected = scan_selection;
  switch (scan_selection)
  {
    case SELECTION_SCAN_CONN: 
    {
      // Current state is scanning,  trying to connect. Turn on associated LED.
      err_code = app_timer_stop(m_scan_slow_blink_timer_id);
                  APP_ERROR_CHECK(err_code);

      NRF_LOG_INFO("Scan mode set: scanning, trying to connect. Will be applied when scanning is re-started.");
    
    } break;
    
    case SELECTION_SCAN_NON_CONN:
    {
    
      // Current state is scanning, not trying to connect. Start blinking associated LED
      err_code = app_timer_start(m_scan_slow_blink_timer_id, SLOW_BLINK_INTERVAL, NULL);
                  APP_ERROR_CHECK(err_code);

      NRF_LOG_INFO("Scan mode set: scanning only. Will be applied when scanning is re-started.");
    } break;
  }

}

/**@brief Function for switching scan selection: "scan-only" or "scan, trying to connect" 
 * Note: this function does only set the internal "scan state", it does not start scanning.
 *       The new scan mode will be used when (re-)starting to scan.
 */
static void on_scan_selection(void) //NOT USED ANYWHERE
{
 // Change the advertising type
  scan_type_seclection_t new_scan_selection;

     
  switch (m_scan_type_selected)
  {
    case SELECTION_SCAN_CONN:  
    {
      // Current state is scanning, not trying to connect. 
      new_scan_selection = SELECTION_SCAN_NON_CONN; 

    } break;
    
    case SELECTION_SCAN_NON_CONN:
    {
      // Current state scanning, trying to connect when target found.
      new_scan_selection = SELECTION_SCAN_CONN;

    } break;
  }
  scan_selection_state_set(new_scan_selection);

}


/**@brief Function for handling Peer Manager events.
 *
 * @param[in] p_evt  Peer Manager event.
 */
static void pm_evt_handler(pm_evt_t const * p_evt)
{
    ret_code_t err_code;
    pm_store_token_t store_token;

    switch (p_evt->evt_id)
    {
        case PM_EVT_BONDED_PEER_CONNECTED:
        {
            NRF_LOG_INFO("Connected to a previously bonded device.");
            if (gear_obj.ble_connected == true)
            {
                gear_obj.ble_secured = true;
            }

        } break;

        case PM_EVT_CONN_SEC_SUCCEEDED:
        {
            NRF_LOG_INFO("Connection secured");
//            NRF_LOG_INFO("Connection secured: role: %d, conn_handle: 0x%x, procedure: %d.",
//                         ble_conn_state_role(p_evt->conn_handle),
//                         p_evt->conn_handle,
//                         p_evt->params.conn_sec_succeeded.procedure);
            if (gear_obj.ble_connected == true)
            {
                gear_obj.ble_secured = true;
            }

        } break;

        case PM_EVT_CONN_SEC_FAILED:
        {
            /* Often, when securing fails, it shouldn't be restarted, for security reasons.
             * Other times, it can be restarted directly.
             * Sometimes it can be restarted, but only after changing some Security Parameters.
             * Sometimes, it cannot be restarted until the link is disconnected and reconnected.
             * Sometimes it is impossible, to secure the link, or the peer device does not support it.
             * How to handle this error is highly application dependent. */
            //pm_handler_disconnect_on_sec_failure(p_evt);
            NRF_LOG_INFO("Failed to secure connection.");
        } break;

        case PM_EVT_CONN_SEC_CONFIG_REQ:
        {
            // Reject pairing request from an already bonded peer.
            pm_conn_sec_config_t conn_sec_config = {.allow_repairing = false};
            pm_conn_sec_config_reply(p_evt->conn_handle, &conn_sec_config);
        } break;

        case PM_EVT_CONN_SEC_PARAMS_REQ:
        {
            //pm_conn_sec_params_reply(p_evt->conn_handle, );
        } break;

        case PM_EVT_STORAGE_FULL:
        {
            // Run garbage collection on the flash.
            err_code = fds_gc();
            if (err_code == FDS_ERR_NO_SPACE_IN_QUEUES)
            {
                // Retry.
            }
            else
            {
                APP_ERROR_CHECK(err_code);
            }
        } break;

        case PM_EVT_PEERS_DELETE_SUCCEEDED:
        {
            // Bonds are deleted. Start scanning.
            scan_start();
        } break;

        case PM_EVT_PEER_DATA_UPDATE_FAILED:
        {
            // Assert.
            APP_ERROR_CHECK(p_evt->params.peer_data_update_failed.error);
        } break;

        case PM_EVT_PEER_DELETE_FAILED:
        {
            // Assert.
            APP_ERROR_CHECK(p_evt->params.peer_delete_failed.error);
        } break;

        case PM_EVT_PEERS_DELETE_FAILED:
        {
            // Assert.
            APP_ERROR_CHECK(p_evt->params.peers_delete_failed_evt.error);
        } break;

        case PM_EVT_ERROR_UNEXPECTED:
        {
            // Assert.
            APP_ERROR_CHECK(p_evt->params.error_unexpected.error);
        } break;

        case PM_EVT_CONN_SEC_START:
        case PM_EVT_PEER_DATA_UPDATE_SUCCEEDED:
        case PM_EVT_PEER_DELETE_SUCCEEDED:
              NRF_LOG_INFO("A peer was deleted.");
          break;
        case PM_EVT_LOCAL_DB_CACHE_APPLIED:
        case PM_EVT_LOCAL_DB_CACHE_APPLY_FAILED:
            // This can happen when the local DB has changed.
        case PM_EVT_SERVICE_CHANGED_IND_SENT:
        case PM_EVT_SERVICE_CHANGED_IND_CONFIRMED:
        default:
            break;
    }
}

/**@brief Function for the Peer Manager initialization.
 */
static void peer_manager_init(void)
{
    ble_gap_sec_params_t sec_param;
    ret_code_t           err_code;

    err_code = pm_init();
                APP_ERROR_CHECK(err_code);

    memset(&sec_param, 0, sizeof(ble_gap_sec_params_t));

    // Security parameters to be used for all security procedures.
    sec_param.bond           = SEC_PARAM_BOND;
    sec_param.mitm           = SEC_PARAM_MITM;
    sec_param.lesc           = SEC_PARAM_LESC;
    sec_param.keypress       = SEC_PARAM_KEYPRESS;
    sec_param.io_caps        = SEC_PARAM_IO_CAPABILITIES;
    sec_param.oob            = SEC_PARAM_OOB;
    sec_param.min_key_size   = SEC_PARAM_MIN_KEY_SIZE;
    sec_param.max_key_size   = SEC_PARAM_MAX_KEY_SIZE;
    sec_param.kdist_own.enc  = 1;
    sec_param.kdist_own.id   = 1;
    sec_param.kdist_peer.enc = 1;
    sec_param.kdist_peer.id  = 1;

    err_code = pm_sec_params_set(&sec_param);
                APP_ERROR_CHECK(err_code);

    err_code = pm_register(pm_evt_handler);
                APP_ERROR_CHECK(err_code);
}

/**@brief Function for initializing the Scanner module.
 */
static void scan_init(void)
{
    ret_code_t          err_code;
    nrf_ble_scan_init_t init_scan;

    memset(&init_scan, 0, sizeof(init_scan));
    
    init_scan.p_scan_param     = &m_scan_param;
    init_scan.connect_if_match = false;
    init_scan.conn_cfg_tag     = APP_BLE_CONN_CFG_TAG;

    err_code = nrf_ble_scan_init(&m_scan_non_conn, &init_scan, scan_evt_handler);
                APP_ERROR_CHECK(err_code);

    // Setting filters for scanning.
    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, /*NRF_BLE_SCAN_NAME_FILTER |*/ NRF_BLE_SCAN_ADDR_FILTER, false);
                APP_ERROR_CHECK(err_code);

    /*err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_NAME_FILTER, m_target_periph_name);
                  APP_ERROR_CHECK(err_code);*/
}


/**@brief Function for initializing the GATT module.
 */
static void gatt_init(void)
{
    ret_code_t err_code = nrf_ble_gatt_init(&m_gatt, gatt_evt_handler);
                            APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling database discovery events.
 *
 * @details This function is callback function to handle events from the database discovery module.
 *          Depending on the UUIDs that are discovered, this function should forward the events
 *          to their respective services.
 *
 * @param[in] p_event  Pointer to the database discovery event.
 */
static void db_disc_handler(ble_db_discovery_evt_t * p_evt)
{
    NRF_LOG_DEBUG("call to ble_cus_service_on_db_disc_evt for instance %d and link 0x%x!",
                  p_evt->conn_handle,
                  p_evt->conn_handle);

    ble_cus_service_on_db_disc_evt(&m_ble_cus_service_client[p_evt->conn_handle], p_evt);
    ble_dfu_service_on_db_disc_evt(&m_ble_dfu_service_client, p_evt);
    
}

/** @brief Database discovery initialization.
 */
static void db_discovery_init(void)
{
    ret_code_t err_code = ble_db_discovery_init(db_disc_handler);
                            APP_ERROR_CHECK(err_code);
}

/**@brief Handles events coming from the CUS Button central module.
 */
static void cus_service_client_evt_handler(ble_cus_service_client_t * p_cus_service_client, ble_cus_service_client_evt_t * p_cus_service_client_evt)
{
    switch (p_cus_service_client_evt->evt_type)
    {
        case BLE_CUS_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE:
        {
            ret_code_t err_code;

            err_code = ble_cus_service_client_handles_assign(&m_ble_cus_service_client[m_conn_handle],
                                                p_cus_service_client_evt->conn_handle,
                                                &p_cus_service_client_evt->params.peer_db);
            NRF_LOG_INFO("cus service discovered on conn_handle 0x%x.", p_cus_service_client_evt->conn_handle);

            // Custom service discovered. Enable notifications on Tx from Peer.
            // err_code = ble_cus_service_tx_notif_enable(&m_ble_cus_service_client);//p_cus_service_client
            //              APP_ERROR_CHECK(err_code);
        } break; // BLE_CUS_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE

        case BLE_CUS_SERVICE_CLIENT_EVT_TX_NOTIFICATION:
        { 
          
            NRF_LOG_INFO("Notif rcvd on link 0x%x: val = 0x%x, len %d", p_cus_service_client_evt->conn_handle, 
                                                                        p_cus_service_client_evt->params.tx.tx_value[0], 
                                                                        p_cus_service_client_evt->params.tx.length);
            notif_packet_processor(p_cus_service_client_evt->params.tx.tx_value, p_cus_service_client_evt->params.tx.length);
        } break; //BLE_CUS_SERVICE_CLIENT_EVT_TX_NOTIFICATION

        default:
            // No implementation needed.
            break;
    }
}

/**@brief Handles events coming from the DFU central module.
 */
static void dfu_service_client_evt_handler(ble_dfu_service_client_t * p_dfu_service_client, ble_dfu_service_client_evt_t * p_dfu_service_client_evt)
{

    switch (p_dfu_service_client_evt->evt_type)
    {
        case BLE_DFU_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE:
        {
            ret_code_t err_code;

            err_code = ble_dfu_service_client_handles_assign(&m_ble_dfu_service_client,
                                                p_dfu_service_client_evt->conn_handle,
                                                &p_dfu_service_client_evt->params.peer_db);
            NRF_LOG_INFO("dfu service discovered on conn_handle 0x%x.", p_dfu_service_client_evt->conn_handle);

        } break; // BLE_DFU_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE

        case BLE_DFU_SERVICE_CLIENT_EVT_TX_NOTIFICATION:
        { 
          
            NRF_LOG_INFO("DFU Notif rcvd on link 0x%x: val = 0x%x, len %d", p_dfu_service_client_evt->conn_handle, 
                                                                        p_dfu_service_client_evt->params.dfu_data.dfu_payload[0], 
                                                                        p_dfu_service_client_evt->params.dfu_data.length);
            // if BLE_DFU_MODE_ACTIVE then directly send the notification data to MT76 side
            if (m_dfu_mode == BLE_DFU_MODE_ACTIVE)
            {
                tx_packet_obj_t tx_packet_obj;
                uint8_t tx_payload[MAX_PAYLOAD];

                tx_packet_obj.data_size = (p_dfu_service_client_evt->params.dfu_data.length+1);
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_DFU_NOTIF_DATA;
                tx_payload[0] = p_dfu_service_client_evt->params.dfu_data.length;
                memcpy(&tx_payload[1], p_dfu_service_client_evt->params.dfu_data.dfu_payload, p_dfu_service_client_evt->params.dfu_data.length);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
            }
        } break; //BLE_DFU_SERVICE_CLIENT_EVT_TX_NOTIFICATION

        case BLE_DFU_SERVICE_CLIENT_EVT_TX_INDICATION:
        { 
          
            NRF_LOG_INFO("DFU Indic rcvd on link 0x%x: val = 0x%x  0x%x  0x%x, len %d", p_dfu_service_client_evt->conn_handle, 
                                                                        p_dfu_service_client_evt->params.dfu_data.dfu_payload[0],
                                                                         p_dfu_service_client_evt->params.dfu_data.dfu_payload[1],
                                                                         p_dfu_service_client_evt->params.dfu_data.dfu_payload[2],
                                                                        p_dfu_service_client_evt->params.dfu_data.length);
        } break; //BLE_DFU_SERVICE_CLIENT_EVT_TX_INDICATION

        default:
            // No implementation needed.
            break;
    }
}

/**@brief Custom Service client initialization.
 */
static void cus_service_client_init(void)
{
    ret_code_t       err_code;
    ble_cus_service_client_init_t cus_service_client_init_obj;

    cus_service_client_init_obj.evt_handler = cus_service_client_evt_handler;

    for (uint32_t i = 0; i < NRF_SDH_BLE_CENTRAL_LINK_COUNT; i++)
    {
        err_code = ble_cus_service_client_init(&m_ble_cus_service_client[i], &cus_service_client_init_obj);
                    APP_ERROR_CHECK(err_code);
    }
}

/**@brief DFU Service client initialization.
 */
static void dfu_service_client_init(void)
{
    ret_code_t       err_code;
    ble_dfu_service_client_init_t dfu_service_client_init_obj;

    dfu_service_client_init_obj.evt_handler = dfu_service_client_evt_handler;

    err_code = ble_dfu_service_client_init(&m_ble_dfu_service_client, &dfu_service_client_init_obj);
                APP_ERROR_CHECK(err_code);
}

/**@brief Function for setting up a filter of all bonded peers/Gears.
 */
void scan_filter_of_bonded_peers(void)
{
    ret_code_t err_code;

    app_timer_stop(m_datascan_process_timer_id);

    err_code = nrf_ble_scan_all_filter_remove(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_disable(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, NRF_BLE_SCAN_ADDR_FILTER, false);
    APP_ERROR_CHECK(err_code);

    // Load Peer IDs to create scan filters
    pm_peer_id_t current_peer_id = pm_next_peer_id_get(PM_PEER_ID_INVALID);
    pm_peer_data_bonding_t current_peer_bonding_data;
    while (current_peer_id != PM_PEER_ID_INVALID)
    {
        // Load bonding data using peer ID, and set scan filter for it - max 20.
        pm_peer_data_bonding_load(current_peer_id, &current_peer_bonding_data);

        err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_ADDR_FILTER, current_peer_bonding_data.peer_ble_id.id_addr_info.addr);
        APP_ERROR_CHECK(err_code);

        current_peer_id = pm_next_peer_id_get(current_peer_id);
    }

    scan_selection_state_set(SELECTION_SCAN_NON_CONN);
    scan_start();
}

/**@brief Function for cycling through and setting a filter for every bonded peer indivdiually. 
 *
 * @details This is used to scan for each bonded peer individually in round-robin fashion.
 * This is the default process of the Brige while no other process is running.
 */
void scan_filter_increment_peer(bool reset)
{
    ret_code_t err_code;

    static pm_peer_id_t current_peer_id = PM_PEER_ID_INVALID;
    static pm_peer_data_bonding_t current_peer_bonding_data;

    // this sets current peer ID to PM_PEER_ID_INVALID in case current peed id is deleted from pm. 
    if (reset)
    {
      current_peer_id = PM_PEER_ID_INVALID;
      return;
    }

    err_code = nrf_ble_scan_all_filter_remove(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_disable(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, NRF_BLE_SCAN_ADDR_FILTER, false);
                APP_ERROR_CHECK(err_code);  

   
    // Load bonding data using peer ID, and set scan filter for it
    current_peer_id = pm_next_peer_id_get(current_peer_id);
    if (current_peer_id == PM_PEER_ID_INVALID)
    {
        current_peer_id = pm_next_peer_id_get(PM_PEER_ID_INVALID);
    }
    // At this point if current peer id is still invalid (no valid peer in memory) then exit, no data scanning.
    if(current_peer_id == PM_PEER_ID_INVALID)
    {
        return;
    }
    err_code = pm_peer_data_bonding_load(current_peer_id, &current_peer_bonding_data);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_ADDR_FILTER, current_peer_bonding_data.peer_ble_id.id_addr_info.addr);
                APP_ERROR_CHECK(err_code);
    
    memcpy(scan_obj.ble_addr, current_peer_bonding_data.peer_ble_id.id_addr_info.addr, 6);
    scan_obj.peer_id = current_peer_id;
    scan_obj.device_found = false;

    scan_selection_state_set(SELECTION_SCAN_NON_CONN);
    scan_start();


}

/**@brief Function for setting up a filter of AXIS Gear V2 named devices.
 */
void scan_filter_provisioning_mode(void)
{
    ret_code_t err_code;

    app_timer_stop(m_datascan_process_timer_id);

    err_code = nrf_ble_scan_all_filter_remove(&m_scan_non_conn); //remove previously set filters
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_disable(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    // Setting filters for scanning.
    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, NRF_BLE_SCAN_NAME_FILTER, false);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_NAME_FILTER, m_target_periph_name);
                APP_ERROR_CHECK(err_code);

    scan_selection_state_set(SELECTION_SCAN_PROVISIONING);
    scan_start();
}

/**@brief Function for setting up a filter of the address provided.
 *
 * @param[in] addr        pointer to address of peer to setup filter for.
 */
void scan_filter_connect_addr(uint8_t * addr)
{
    ret_code_t err_code;

    app_timer_stop(m_datascan_process_timer_id);

    err_code = nrf_ble_scan_all_filter_remove(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_disable(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, NRF_BLE_SCAN_ADDR_FILTER, false);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_ADDR_FILTER, addr);
                APP_ERROR_CHECK(err_code);

    scan_selection_state_set(SELECTION_SCAN_CONN);
    scan_start();
}

/**@brief Function for setting up a filter of DFU address provided.
 *        the address LSB is incremented by one, and name DfuTarger is added.
 * @param[in] addr        pointer to address of peer to setup filter for.
 */
void scan_filter_dfu_addr(uint8_t * addr)
{
    ret_code_t err_code;

    app_timer_stop(m_datascan_process_timer_id);

    err_code = nrf_ble_scan_all_filter_remove(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_disable(&m_scan_non_conn);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filters_enable(&m_scan_non_conn, NRF_BLE_SCAN_ADDR_FILTER, false);
                APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_scan_filter_set(&m_scan_non_conn, SCAN_ADDR_FILTER, addr);
                APP_ERROR_CHECK(err_code);

    scan_selection_state_set(SELECTION_SCAN_CONN);
    scan_start();
}

/**@brief Function for running the BLE DFU process state machine to update Gear V2 firmware over BLE.
 *
 *@param[in] p_gear_obj         pointer to gear object containing details of target Gear.
*/
static void gear_ble_dfu_process_sm(gear_obj_t * p_gear_obj, gear_ble_dfu_process_sm_t m_state)
{
    ret_code_t err_code;

    static uint16_t exit_timer = 0;
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];
    static gear_ble_dfu_process_sm_t state = SETUP_TARGET_FILTER;

    exit_timer++;

    if(m_state == DFU_COMPLETE)
    {
        state = m_state;
    }

    switch(state)
    {
        case SETUP_TARGET_FILTER:
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
            // Initiate connection.
                m_conn_param.min_conn_interval = CONN_INTERVAL_DFU;
                m_conn_param.max_conn_interval = CONN_INTERVAL_DFU; //CONN_INTERVAL_MAX
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("SETUP_TARGET_FILTER Complete");
                state = CHECK_TARGET_CONNECTED;
                exit_timer = 0;
            }
            break;

        case CHECK_TARGET_CONNECTED:
            if (p_gear_obj->ble_connected && p_gear_obj->ble_secured && m_ble_dfu_service_client.conn_handle != BLE_CONN_HANDLE_INVALID) 
            {
                err_code = ble_dfu_service_tx_indic_enable(&m_ble_dfu_service_client, true);
                            APP_ERROR_CHECK(err_code);
                NRF_LOG_INFO("Target Connected");
                state = SEND_DFU_COMMAND;
                exit_timer = 0;
            }
            else if (exit_timer >= 300) //30 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = DFU_COMPLETE;
            }
            break;
        
        case SEND_DFU_COMMAND:
            scan_selection_state_set(SELECTION_SCAN_PAUSED);
            static uint8_t cmd = 0x01u;
            err_code = ble_dfu_service_buttonless_command_send(&m_ble_dfu_service_client, &cmd);
                        APP_ERROR_CHECK(err_code);
            NRF_LOG_INFO("Enter DFU command sent");
            state = CHECK_TARGET_DISCONNECTED;
            exit_timer = 0;
            break;
        
        case CHECK_TARGET_DISCONNECTED:
            if (p_gear_obj->ble_connected == false && p_gear_obj->ble_secured == false)
            {
                NRF_LOG_INFO("TARGET DISCONNECT Complete");
                state = SETUP_DFU_FILTER; 
                exit_timer = 0;
            }
            else if (exit_timer >= 300) //30 seconds
            {
                state = DFU_COMPLETE;
            }
            break;

        case SETUP_DFU_FILTER:
            // Increment BLE address and connect
            p_gear_obj->gear_addr[0] = p_gear_obj->gear_addr[0]+1;
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("SETUP_DFU_FILTER Complete");
                state = CHECK_DFU_CONNECTED;
                exit_timer = 0;
            }
            break;
        
        case CHECK_DFU_CONNECTED:
            if (p_gear_obj->ble_connected && m_ble_dfu_service_client.conn_handle != BLE_CONN_HANDLE_INVALID/*&& p_gear_obj->ble_secured*/) //No security exchange for unbonded ble bootloader.
            {
                err_code = ble_dfu_service_tx_notif_enable(&m_ble_dfu_service_client, true);
                            APP_ERROR_CHECK(err_code);
                NRF_LOG_INFO("DfuTarg Connected");
                state = REPORT_READY_MT76;
                exit_timer = 0;
            }
            else if (exit_timer >= 300) //30 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = DFU_COMPLETE;
            }
            break;

        case REPORT_READY_MT76:
            tx_packet_obj.data_size = 6;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_DFU_TARG_READY;
            memcpy(tx_payload, p_gear_obj->gear_addr, 6);
            tx_packet_obj.p_payload = tx_payload; 

            tx_packet_processor(&tx_packet_obj);
            state = SET_DFU_MODE_ACTIVE;
            break;
        
        case SET_DFU_MODE_ACTIVE:
            m_dfu_mode = BLE_DFU_MODE_ACTIVE;
            //app_timer_stop(m_ble_dfu_process_timer_id);
            state = BLE_DFU_STATE_WAIT;
            break;
        
        case BLE_DFU_STATE_WAIT:
            if (p_gear_obj->ble_connected == false && p_gear_obj->ble_secured == false)
            {
                NRF_LOG_INFO("TARGET DISCONNECTED!");
                m_dfu_mode = BLE_DFU_MODE_INACTIVE;
                p_gear_obj->gear_addr[0] = p_gear_obj->gear_addr[0]-1; //decrement as it will increment again.
                state = SETUP_DFU_FILTER; 
                exit_timer = 0;
                //app_timer_start(m_ble_dfu_process_timer_id, BLE_DFU_INTERVAL, NULL);
            }
            break;

        case SEND_CONTROL_CMD: //UNUSED
            NRF_LOG_INFO("SEND_CONTROL_CMD");
            state = BLE_DFU_STATE_WAIT;
            break;
        
        case SEND_PACKET_DATA: //UNUSED
            NRF_LOG_INFO("SEND_PACKET_DATA");
            state = BLE_DFU_STATE_WAIT;
            break;

        case DFU_COMPLETE:            
            // disconnect
            app_timer_stop(m_ble_dfu_process_timer_id); //if this timer is running at this point.
            NRF_LOG_INFO("DFU_COMPLETE");

            m_dfu_mode = BLE_DFU_MODE_INACTIVE;
            
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                            APP_ERROR_CHECK(err_code);
            }

            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;

            scan_selection_state_set(SELECTION_SCAN_NON_CONN);
            scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);

            state = SETUP_TARGET_FILTER;
            exit_timer = 0;
            m_bridge_busy = false;
            break;

        default:
            break;
    }
}

/**@brief Function for getting a gear temperature.
 *
 * @param[in] p_gear_obj        pointer to gear object containing details of targer Gear.
 */
static void get_gear_temp_process_sm(gear_obj_t * p_gear_obj)
{
    ret_code_t err_code;

    static uint16_t exit_timer = 0;

    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];

    static get_gear_temp_process_sm_t state = CREATE_TARGET_FILTER;

    static uint16_t peer_id;

    exit_timer++;

    switch(state)
    {   
        case CREATE_TARGET_FILTER:
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
                m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT;
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("CREATE_TARGET_FILTER Complete");
                state = VERIFY_TARGET_CONNECTED;
                exit_timer = 0;
            }
            break;

        case VERIFY_TARGET_CONNECTED:
            if (p_gear_obj->ble_connected && p_gear_obj->ble_secured && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                NRF_LOG_INFO("CONNECT Complete");
                err_code = pm_peer_id_get(m_conn_handle, &peer_id);
                            APP_ERROR_CHECK(err_code);
                state = SEND_GET_TEMP_CMD;
                exit_timer = 0;
            }
            else if (exit_timer >= 600) //30 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE_TEMP;
            }
            break;

        case SEND_GET_TEMP_CMD:
            tx_packet_obj.data_size = 0;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = GET_GEARS_TEMPERATURE;
            tx_payload[0] = NULL;
            tx_packet_obj.p_payload = NULL;

            ble_packet_processor(&tx_packet_obj, 1);

            state = WAIT_FOR_TEMP;  
            message_signal = 0;
            exit_timer = 0;
            break;

        case WAIT_FOR_TEMP:
            if (message_signal == 4)
            {
                message_signal = 0;
                state = COMPLETE_TEMP;
            }
            else if (exit_timer >= 500) //5 sec
            {
                message_signal = 0;
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_NO_FEEDBACK;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE_TEMP;
            }
            break;

        case COMPLETE_TEMP:
            // disconnect
            app_timer_stop(m_get_temperature_timer_id);
            NRF_LOG_INFO("COMPLETE_TEMP");
            
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                            APP_ERROR_CHECK(err_code);
            }

            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;

            scan_selection_state_set(SELECTION_SCAN_NON_CONN);
            scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);

            state = CREATE_TARGET_FILTER;
            exit_timer = 0;
            m_bridge_busy = false;
            break;

        default:
           break;
    }
}

/**@brief Function for setting a gear name.
 *
 * @param[in] p_gear_obj        pointer to gear object containing details of targer Gear.
 */
static void set_gear_name_process_sm(gear_obj_t * p_gear_obj)
{
    ret_code_t err_code;

    static uint16_t exit_timer = 0;
    
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];

    static set_gear_name_process_sm_t state = CREATE_SCAN_FILTER;

    static uint16_t peer_id;

    exit_timer++;

    switch(state)
    {   
        case CREATE_SCAN_FILTER:
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
                m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT;
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("CREATE_SCAN_FILTER Complete");
                state = VERIFY_CONNECTED;
                exit_timer = 0;
            }
            break;

        case VERIFY_CONNECTED:
            if (p_gear_obj->ble_connected && p_gear_obj->ble_secured && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                NRF_LOG_INFO("CONNECT Complete");
                err_code = pm_peer_id_get(m_conn_handle, &peer_id);
                            APP_ERROR_CHECK(err_code);
                state = SEND_GEAR_NAME;
                exit_timer = 0;
            }
            else if (exit_timer >= 600) //30 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE_NAMING;
            }
            break;

        case SEND_GEAR_NAME:
            tx_packet_obj.data_size = p_gear_obj->name_len + 1;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = SET_GEAR_NAME;
            tx_payload[0] = p_gear_obj->name_len;
            memcpy(&tx_payload[1], p_gear_obj->gear_name, p_gear_obj->name_len);
            tx_packet_obj.p_payload = tx_payload;

            p_gear_obj->name_len = 0;
            memset(p_gear_obj->gear_name, 0, 20);

            ble_packet_processor(&tx_packet_obj, 1);

            state = WAIT_FOR_NAME;  
            message_signal = 0;
            exit_timer = 0;
            break;

        case WAIT_FOR_NAME:
            if (message_signal == 1)
            {
                message_signal = 0;
                state = COMPLETE_NAMING;
            }
            else if (exit_timer >= 500) //5 sec
            {
                message_signal = 0;
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_NO_FEEDBACK;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE_NAMING;
            }
            break;

        case COMPLETE_NAMING:
            // disconnect
            app_timer_stop(m_set_name_command_timer_id);
            NRF_LOG_INFO("COMPLETE_NAMING");
            
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                            APP_ERROR_CHECK(err_code);
            }

            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;

            scan_selection_state_set(SELECTION_SCAN_NON_CONN);
            scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);

            state = CREATE_SCAN_FILTER;
            exit_timer = 0;
            m_bridge_busy = false;
            break;

        default:
           break;
    }

}

/**@brief Function for deleting bonding info of a Gear, and causing it to also delete bond of bridge.
 *
 * @param[in] p_gear_obj        pointer to gear object containing details of targer Gear.
 */
static void bond_delete_process_sm(gear_obj_t * p_gear_obj)
{
    ret_code_t err_code;
    
    static uint16_t exit_timer = 0;
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];
    static bond_delete_process_sm_t state = SETUP_DEVICE_FILTER;

    static uint16_t peer_id; 

    exit_timer++;

    switch(state)
    {
        case SETUP_DEVICE_FILTER:
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("SETUP_SCAN_FILTER Complete");
                state = CHECK_CONNECTION;
                exit_timer = 0;
            }
            break;

        case CHECK_CONNECTION:
            if (p_gear_obj->ble_connected && p_gear_obj->ble_secured && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                NRF_LOG_INFO("CONNECT Complete");
                err_code = pm_peer_id_get(m_conn_handle, &peer_id);
                            APP_ERROR_CHECK(err_code);
                //make sure this peer_id corresponds to the Gear BLE Address to be deleted:
                //load bonding data using this peer id and compare peer_ble_id to p_gear_obj->gear_addr
                state = SEND_DELETE_REQUEST;
                exit_timer = 0;
            }
            else if (exit_timer >= 600) //30 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = DELETE_COMPLETE;
            }
            break;

        case SEND_DELETE_REQUEST:
            scan_selection_state_set(SELECTION_SCAN_PAUSED);

            tx_packet_obj.data_size = 0;
            tx_packet_obj.primary_header = COMMAND_PROTO_UTILITY;
            tx_packet_obj.secondary_headers.header_type.gear_header = SET_GEAR_DELETE_BOND;
            tx_packet_obj.p_payload = NULL;

            ble_packet_processor(&tx_packet_obj, 1);
            NRF_LOG_INFO("DELETE REQUEST Sent");
            state = CHECK_DISCONNECTED;
            exit_timer = 0;
            break;
        
        case CHECK_DISCONNECTED:
            if (p_gear_obj->ble_connected == false && p_gear_obj->ble_secured == false)
            {
                NRF_LOG_INFO("DISCONNECT Complete");
                state = DELETE_PEER_BOND; 
                exit_timer = 0;
            }
            else if (exit_timer >= 100) //5 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_DELETE_ERROR;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = DELETE_COMPLETE;//DELETE_PEER_BOND;
            }
            break;

        case DELETE_PEER_BOND:
            
            err_code = pm_peer_delete(peer_id);
                        APP_ERROR_CHECK(err_code);
            scan_filter_increment_peer(true);
            NRF_LOG_INFO("DELETE PEER BOND Complete");
            state = CONFIRM_TO_MT76; 
            exit_timer = 0;
            break;
        
        case CONFIRM_TO_MT76:
            // write feedback
            tx_packet_obj.data_size = 6;
            tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_DELETE_SUCCESS;
            memcpy(tx_payload, p_gear_obj->gear_addr, 6);
            tx_packet_obj.p_payload = tx_payload; 

            tx_packet_processor(&tx_packet_obj);
            NRF_LOG_INFO("CONFIRMED DELETE TO MT76");
            state = DELETE_COMPLETE;
            exit_timer = 0;
            break;

        case DELETE_COMPLETE:
            app_timer_stop(m_bond_delete_process_timer_id);
            NRF_LOG_INFO("DELETE Complete");
            
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                            APP_ERROR_CHECK(err_code);
            }
//
            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;

            //scan_filter_of_bonded_peers();
            scan_selection_state_set(SELECTION_SCAN_PAUSED);
            //scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);
            state = SETUP_DEVICE_FILTER;
            exit_timer = 0;
            m_bridge_busy = false;
            break;

        default:
            break;
    }
}

/**@brief Function for running the provision process state-machine.
 *
 * @details This function runs in a timer iteratively until terminal state.
 *
 * @param[in] p_gear_obj        pointer to gear object.
 */
static void provision_process_sm(gear_obj_t * p_gear_obj)
{
    ret_code_t err_code;
    
    static uint16_t exit_timer = 0;
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];
    static provision_process_sm_t state = SETUP_SCAN_FILTER;
  
    exit_timer++;

    switch (state)
    {
        case SETUP_SCAN_FILTER:
            nrf_gpio_pin_set(LED_RING_SWITCH);
            if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
                m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT; //CONN_INTERVAL_MAX
                scan_filter_connect_addr(p_gear_obj->gear_addr);
                NRF_LOG_INFO("SETUP_SCAN_FILTER Complete");
                state = CHECK_PROVISIONED_CONNECTED;
                exit_timer = 0;
            }
            break;

        case CHECK_PROVISIONED_CONNECTED:
            if (p_gear_obj->ble_connected && p_gear_obj->ble_secured && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                ble_cus_service_tx_notif_enable(&m_ble_cus_service_client[m_conn_handle], true);
                NRF_LOG_INFO("CONNECT/PROVISION Complete");
                state = SET_BRIDGED_MODE;
                exit_timer = 0;
            }
            else if (exit_timer >= 500) //5 sec
            {
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE;
            }
            break;

        case SET_BRIDGED_MODE:
            // command to Gear
            tx_packet_obj.data_size = 0;
            tx_packet_obj.primary_header = COMMAND_PROTO_UTILITY;
            tx_packet_obj.secondary_headers.header_type.gear_header = SET_GEAR_BRIDGED_MODE;
            //tx_payload[0] = ;
            tx_packet_obj.p_payload = NULL;

            ble_packet_processor(&tx_packet_obj, 1);

            state = REPORT_TO_MT76;  
            exit_timer = 0;
            break;

        case REPORT_TO_MT76:
            // write feedback
            tx_packet_obj.data_size = 6;
            tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_CONNECT_PROV_SUCCESS;
            memcpy(tx_payload, p_gear_obj->gear_addr, 6);
            tx_packet_obj.p_payload = tx_payload; 

            tx_packet_processor(&tx_packet_obj);
            NRF_LOG_INFO("FEEDBACK_TO_MT76 Complete");
            state = WAIT_FOR_INFO;//COMPLETE;
            message_signal = 0;
            exit_timer = 0;

            // send GET_GEAR_INFO to Gear to get name, fw/hw verson.
            tx_packet_obj.data_size = 0;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = GET_GEARS_INFO;
            //tx_payload[0] = ;
            tx_packet_obj.p_payload = NULL;
            ble_packet_processor(&tx_packet_obj, 1);
            break;

        case WAIT_FOR_INFO:
            if (message_signal == 3)
            {
                message_signal = 0;
                state = COMPLETE;
            }
            else if (exit_timer >= 500) //5 sec
            {
                message_signal = 0;
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_NO_FEEDBACK;
                memcpy(&tx_payload, p_gear_obj->gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
                state = COMPLETE;
            }
            break;

        case COMPLETE:
            // disconnect
            nrf_gpio_pin_clear(LED_RING_SWITCH);
            app_timer_stop(m_provision_process_timer_id);
            app_timer_stop(m_provisioning_mode_timer_id);
            NRF_LOG_INFO("DISCONNECTED");

            scan_selection_state_set(SELECTION_SCAN_PAUSED);
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                            APP_ERROR_CHECK(err_code);
            }

            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;

            //scan_filter_of_bonded_peers();
            scan_selection_state_set(SELECTION_SCAN_NON_CONN);
            scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);

            state = SETUP_ADDR_FILTER;
            exit_timer = 0;
            m_bridge_busy = false;
            break;

        default:
            break;
    }
}

/**@brief Function for running the position process state-machine.
 *
 * @details This function runs in a timer iteratively until terminal state.
 *
 * @param[in] p_grp_obj        pointer to gear group object.
 */
static void position_command_process_sm(group_obj_t * p_grp_obj, position_command_process_sm_t m_state)
{
    ret_code_t err_code;
    static uint16_t exit_timer = 0;
    static uint8_t grp_member = 0;
    static uint8_t reconnect_grp_member = 0xFF;
    
    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD]; uint8_t length = 6;
    static position_command_process_sm_t state = SETUP_ADDR_FILTER;

    ble_node_t* ble_node;

    exit_timer++;

    static uint32_t connection_timer = 0; //testing connection time.
    
    //state transitions
//    switch (state)
//    {   
//        case SETUP_ADDR_FILTER:
//            break;
//        case CHECK_CONNECTED:
//            break;
//        case SEND_POSITION:
//            break;
//        case AWAIT_FEEDBACK:
//            break;
//        case FEEDBACK_TO_MT76:
//            break;
//        case WAIT_STATE:
//            break;
//        case SETUP_RECONNECT_ADDR:
//            break;
//        case CHECK_RECONNECTED:
//            break;
//        case DISCONNECT: 
//            break;
//        default:
//          break;
//    }

    // state actions
    switch (state)
    {
        case SETUP_ADDR_FILTER:
            //if(m_conn_handle == BLE_CONN_HANDLE_INVALID)
            //{
                m_conn_param.min_conn_interval = CONN_INTERVAL_DEFAULT;
                m_conn_param.max_conn_interval = CONN_INTERVAL_DEFAULT; //CONN_INTERVAL_MAX
                scan_filter_connect_addr(p_grp_obj->grp_gear_obj[grp_member].gear_addr);
                memcpy(gear_obj.gear_addr, p_grp_obj->grp_gear_obj[grp_member].gear_addr, 6);
                gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;
                NRF_LOG_INFO("SETUP_ADDR_FILTER Complete: gear: %x, memb: %d", p_grp_obj->grp_gear_obj[grp_member].gear_addr[0], grp_member);
                state = CHECK_CONNECTED;
                exit_timer = 0;
            //}
            //else
            //{
            //    state = CHECK_CONNECTED;
            //    exit_timer = 0;
            //}
            break;

        case CHECK_CONNECTED:
            connection_timer++;
            if (gear_obj.ble_connected && gear_obj.ble_secured && !gear_obj.ble_notif_en && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                NRF_LOG_INFO("CHECK_CONNECTED Complete, time: %d ms", (connection_timer*50));
                connection_timer = 0;
                ble_cus_service_tx_notif_enable(&m_ble_cus_service_client[m_conn_handle], true);
                p_grp_obj->grp_gear_obj[grp_member].ble_connected = true;
                p_grp_obj->grp_gear_obj[grp_member].ble_secured = true;
                p_grp_obj->grp_gear_obj[grp_member].ble_notif_en = true; gear_obj.ble_notif_en = true;
                p_grp_obj->grp_gear_obj[grp_member].conn_handle = gear_obj.conn_handle;
                // Add to ble link-list
                //insert_first_ble_node(gear_obj.conn_handle, gear_obj.gear_addr);
                exit_timer = 0;
                grp_member++;
                grp_member == (p_grp_obj->grp_size) ? (state = SEND_POSITION) : (state = SETUP_ADDR_FILTER);
            }
            else if (exit_timer >= 150) //7.5 sec
            {
                connection_timer = 0;
                // ERROR Gear not found:
                tx_packet_obj.data_size = 6;
                tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                memcpy(&tx_payload, p_grp_obj->grp_gear_obj[grp_member].gear_addr, 6);
                tx_packet_obj.p_payload = tx_payload; 
                // Move on to next Gear if there's more
                grp_member++; //= 0;
                grp_member == (p_grp_obj->grp_size) ? (state = SEND_POSITION) : (state = SETUP_ADDR_FILTER);

                tx_packet_processor(&tx_packet_obj);
                //state = DISCONNECT;
            }
            break;

        case SEND_POSITION:
            grp_member = (p_grp_obj->grp_size - 1);//--;
            // Send position to Gear
            tx_packet_obj.data_size = 1;
            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
            tx_packet_obj.secondary_headers.header_type.gear_header = SET_GEARS_POSITION;
            tx_payload[0] = p_grp_obj->grp_gear_obj[grp_member].position; //same position for all Gears
            tx_packet_obj.p_payload = tx_payload;

            ble_packet_processor(&tx_packet_obj, p_grp_obj->grp_size);
            NRF_LOG_INFO("SEND_POSITION Complete");
            //grp_member == 0 ? (state = FEEDBACK_TO_MT76) : (state = SEND_POSITION);
            state = WAIT_STATE;
            exit_timer = 0;
            break;

          case WAIT_STATE:
              if (m_state == SEND_POSITION)
              {
                  state = m_state;
              }
              if(exit_timer >= 180)// 1800:1.5 min 180:9sec
              {
                  state = DISCONNECT;
              }
              // if a disconnect took place, see on what connection handle and try to re-connect that one
              else if (gear_obj.ble_connected == false && gear_obj.ble_secured == false && gear_obj.ble_notif_en == false)
              {
                //ble_node = find_ble_node(gear_obj.conn_handle);  
                //ble_node->ble_addr
                //(void)delete_ble_node(gear_obj.conn_handle);
                for(int i = 0; i < p_grp_obj->grp_size; i++)
                {
                    if (p_grp_obj->grp_gear_obj[i].conn_handle == gear_obj.conn_handle)
                    {
                        //dropped connection on group gear of index i: 
                        //p_grp_obj->grp_gear_obj[i].gear_addr
                        memcpy(gear_obj.gear_addr, p_grp_obj->grp_gear_obj[i].gear_addr, 6);
                        p_grp_obj->grp_gear_obj[i].ble_connected = true;
                        p_grp_obj->grp_gear_obj[i].ble_secured = true;
                        p_grp_obj->grp_gear_obj[i].ble_notif_en = true; 
                        reconnect_grp_member = i;
                        state = SETUP_RECONNECT_ADDR;
                        break;
                    }
                }
                exit_timer = 0;
              }
              break;

          case SETUP_RECONNECT_ADDR:
              scan_filter_connect_addr(gear_obj.gear_addr);
              gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;
              NRF_LOG_INFO("SETUP_RECONNECT_ADDR");
              state = CHECK_RECONNECTED;
              exit_timer = 0;
              break;

          case CHECK_RECONNECTED:
              if (gear_obj.ble_connected && gear_obj.ble_secured && !gear_obj.ble_notif_en && m_ble_cus_service_client[m_conn_handle].conn_handle != BLE_CONN_HANDLE_INVALID)
              {
                NRF_LOG_INFO("CHECK_RECONNECTED Complete");
                ble_cus_service_tx_notif_enable(&m_ble_cus_service_client[m_conn_handle], true);
                p_grp_obj->grp_gear_obj[reconnect_grp_member].ble_connected = true;
                p_grp_obj->grp_gear_obj[reconnect_grp_member].ble_secured = true;
                p_grp_obj->grp_gear_obj[reconnect_grp_member].ble_notif_en = true; gear_obj.ble_notif_en = true;
                p_grp_obj->grp_gear_obj[reconnect_grp_member].conn_handle = gear_obj.conn_handle;
                exit_timer = 0;
                state = WAIT_STATE;
              }
              else if (exit_timer >= 150) //7.5 sec
              {
                  // ERROR Gear not found:
                  tx_packet_obj.data_size = 6;
                  tx_packet_obj.primary_header = COMMAND_PROTO_NETWORK;
                  tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NOT_FOUND;
                  memcpy(&tx_payload, p_grp_obj->grp_gear_obj[reconnect_grp_member].gear_addr, 6);
                  tx_packet_obj.p_payload = tx_payload; 

                  tx_packet_processor(&tx_packet_obj);
                  state = DISCONNECT;
              }
              break;

//        case AWAIT_FEEDBACK: // now directly in notif_decoder
//            //await a feedback over BLE
//            if (grp_obj.grp_gear_obj[0].rprt_pos == p_grp_obj->grp_gear_obj[0].position)
//            {
//                state = FEEDBACK_TO_MT76;
//                exit_timer = 0;
//            }
//            else if (exit_timer >= 1800) //3 min
//            {
//                //NO_FEEDBACK
//                tx_packet_obj.data_size = 6;
//                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
//                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_NO_FEEDBACK;
//                memcpy(&tx_payload, p_grp_obj->grp_gear_obj[0].gear_addr, 6);
//                tx_packet_obj.p_payload = tx_payload; 
//
//                tx_packet_processor(&tx_packet_obj);
//                state = DISCONNECT;
//            }
//            break;
//
//        case FEEDBACK_TO_MT76: // now directly in notif_decoder
//            // write feedback
//            tx_packet_obj.data_size = 7;
//            tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
//            tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_POSITION;
//            tx_payload[0] = p_grp_obj->grp_gear_obj[0].position;
//            memcpy(&tx_payload[1], p_grp_obj->grp_gear_obj[0].gear_addr, 6);
//            tx_packet_obj.p_payload = tx_payload; 
//
//            tx_packet_processor(&tx_packet_obj);
//            NRF_LOG_INFO("FEEDBACK_TO_MT76 Complete");
//            state = WAIT_STATE;//DISCONNECT;
//            exit_timer = 0;
//            break;

        case DISCONNECT:
            // disconnect
            app_timer_stop(m_position_command_timer_id);
            NRF_LOG_INFO("DISCONNECT Complete");

            scan_selection_state_set(SELECTION_SCAN_PAUSED);
            if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
            {
                for (uint32_t i = 0; i<=m_conn_handle ; i++) //p_grp_obj->grp_size
                {
                    //(void)delete_ble_node(m_conn_handle);
                    err_code = sd_ble_gap_disconnect(i, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                                APP_ERROR_CHECK(err_code); //m_conn_handle
                }
            }

            gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;
            for (grp_member = 0; grp_member < p_grp_obj->grp_size; grp_member++)
            {
                grp_obj.grp_gear_obj[grp_member].ble_connected = false; 
                grp_obj.grp_gear_obj[grp_member].ble_secured = false; 
                grp_obj.grp_gear_obj[grp_member].ble_notif_en = false;
            }
            //scan_filter_of_bonded_peers();
            scan_selection_state_set(SELECTION_SCAN_NON_CONN);
            scan_start();
            app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);

            state = SETUP_SCAN_FILTER;
            exit_timer = 0;
            grp_member = 0;
            m_bridge_busy = false;
            break;

        default:
            break;
    }
}

/**@brief Function for decoding the command from payload using primary and seconday headers.
 *
 * @param[in] payload        pointer to payload received.
 */
void command_decoder(uint8_t *payload, uint8_t size)
{
    ret_code_t err_code;

    bridge_protocol_primary_headers_t primaryHeader;
    //uint8_t secondaryHeader;
    primaryHeader = payload[0];
    //secondaryHeader = payload[1];

    switch (primaryHeader)
    {
        case COMMAND_PROTO_GEARS:
            if (payload[1] == SET_GEARS_POSITION)
            {
                m_bridge_busy = true;
                grp_obj.grp_size = payload[3];
                for (int i = 0; i < payload[3]; i++)
                {
                    if(payload[2] > 100) // if a position >100 arrives, truncate to 100.
                    {
                        payload[2] = 100; 
                    }
                    grp_obj.grp_gear_obj[i].position = payload[2];
                    memcpy(grp_obj.grp_gear_obj[i].gear_addr, &payload[(4+6*i)], 6);
                }
                //NRF_LOG_INFO("Position Command grp:%d, 1: %x, 2: %x", payload[3], grp_obj.grp_gear_obj[0].gear_addr[0], grp_obj.grp_gear_obj[1].gear_addr[0]);
                position_command_process_sm(&grp_obj, SEND_POSITION);
                app_timer_start(m_position_command_timer_id, PROCESS_SM_INTERVAL, NULL);
            }
            else if (payload[1] == SET_GEAR_NAME)
            {
                m_bridge_busy = true;
                memcpy(gear_obj.gear_addr, &payload[2], 6);
                gear_obj.name_len = payload[8];
                memcpy(gear_obj.gear_name, &payload[9], payload[8]); 
                app_timer_start(m_set_name_command_timer_id, PROCESS_SM_INTERVAL, NULL);
            }
            else if (payload[1] == GET_GEARS_TEMPERATURE)
            {
                m_bridge_busy = true;
                memcpy(gear_obj.gear_addr, &payload[2], 6);        
                app_timer_start(m_get_temperature_timer_id, PROCESS_SM_INTERVAL, NULL);
            }
            else if (payload[1] == SET_GEAR_DFU_MODE)
            {
                m_bridge_busy = true;
                memcpy(gear_obj.gear_addr, &payload[2], 6);
                app_timer_start(m_ble_dfu_process_timer_id, BLE_DFU_INTERVAL, NULL);
            }
            else if (payload[1] == WRITE_DFU_CNTRL_CMD && m_dfu_mode == BLE_DFU_MODE_ACTIVE)
            {
                uint8_t cntrl_packet[payload[2]];
                memcpy(cntrl_packet, &payload[3], payload[2]);
                //gear_ble_dfu_process_sm(&gear_obj, SEND_CONTROL_CMD);
                ble_dfu_service_control_command_send(&m_ble_dfu_service_client, cntrl_packet, payload[2]);
                //NRF_LOG_INFO("CTRL: %x - %x", cntrl_packet[0], cntrl_packet[(payload[2]-1)]);
            }
            else if (payload[1] == WRITE_DFU_PCKT_DATA && m_dfu_mode == BLE_DFU_MODE_ACTIVE)
            {
                uint8_t dfu_packet[payload[2]];
                memcpy(dfu_packet, &payload[3], payload[2]);
                //gear_ble_dfu_process_sm(&gear_obj, SEND_PACKET_DATA);
                ble_dfu_service_data_send(&m_ble_dfu_service_client, dfu_packet, payload[2]);
                            //APP_ERROR_CHECK(err_code);
                //NRF_LOG_INFO("DFU: %x - %x", dfu_packet[0], dfu_packet[(payload[2]-1)]);
            }
            else if (payload[1] == SET_BLE_DFU_COMPLETE /*&& m_dfu_mode == BLE_DFU_MODE_ACTIVE*/)
            {
                gear_ble_dfu_process_sm(&gear_obj, DFU_COMPLETE);
            }
            break;
        
        case COMMAND_PROTO_NETWORK:
            if (payload[1] == DISCONNECT_ALL)
            {
                if(m_conn_handle != BLE_CONN_HANDLE_INVALID)
                {
                    err_code = sd_ble_gap_disconnect(m_conn_handle,BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
                                APP_ERROR_CHECK(err_code);
                }
                gear_obj.ble_connected = false; gear_obj.ble_secured = false; gear_obj.ble_notif_en = false;
                //scan_filter_of_bonded_peers();
                scan_selection_state_set(SELECTION_SCAN_NON_CONN);
                scan_start();
                app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);
            }
            else if (payload[1] == SET_PROVISION_MODE)
            {
                m_bridge_busy = true;
                scan_filter_provisioning_mode();
                app_timer_start(m_provisioning_mode_timer_id, PROVISION_MODE_TIMEOUT, NULL);
            }
            else if (payload[1] == CONNECT_SPECIFIED_GEAR)
            {
                memcpy(gear_obj.gear_addr, &payload[2], 6);
                app_timer_start(m_provision_process_timer_id, PROCESS_SM_INTERVAL, NULL);
            }
            else if (payload[1] == DELETE_PROVISIONED_GEAR)
            {
                m_bridge_busy = true;
                memcpy(gear_obj.gear_addr, &payload[2], 6);
                app_timer_start(m_bond_delete_process_timer_id, PROCESS_SM_INTERVAL, NULL);
            }
            break;

        case COMMAND_PROTO_UTILITY:
            if (payload[1] == SET_NRF_SERIAL_DFU)
            {
                // Reset into UART Bootloader DFU mode.
                sd_power_gpregret_set(0x00,BOOTLOADER_DFU_START);
                sd_power_gpregret_set(0x01, BOOTLOADER_DFU_SKIP_CRC);
                nrf_pwr_mgmt_shutdown(NRF_PWR_MGMT_SHUTDOWN_GOTO_DFU);
            }
            break;       
        
        default:
            break;
    }
}

/**@brief Function for decoding the payload from nofication data using primary/secondary headers.
 *
 * @param[in] payload        pointer to payload received from BLE notifcation.
 */
void notif_decoder(uint8_t *payload)
{
    ret_code_t err_code;

    bridge_protocol_primary_headers_t primaryHeader;
    primaryHeader = payload[0];

    tx_packet_obj_t tx_packet_obj;
    uint8_t tx_payload[MAX_PAYLOAD];
    //NRF_LOG_INFO("NOTIF POS: %x %x %x", payload[0], payload[1], payload[2]);
    switch (primaryHeader)
    {
        case COMMAND_PROTO_GEARS:
            if(payload[1] == REPORT_GEAR_POSITION)
            {
                
                gear_obj.rprt_pos = payload[2];
                //send it straight to MT76:
                tx_packet_obj.data_size = 8;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_POSITION;
                tx_payload[0] = payload[2]; //position
                tx_payload[1] = payload[3];// position-state
                memcpy(&tx_payload[2], &payload[4], 6); //Gear will send it's address
                tx_packet_obj.p_payload = tx_payload; 

                tx_packet_processor(&tx_packet_obj);
            }
            else if(payload[1] == REPORT_GEAR_NAME)
            {
                //send it straight to MT76:
                tx_packet_obj.data_size = 11;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_NAME;                
                memcpy(&tx_payload[0], gear_obj.gear_addr, 6); //Gear can't send address as characteristic payload size limit 20 
                tx_payload[6] = payload[2]; 
                memcpy(&tx_payload[7], &payload[3], payload[2]);
                tx_packet_obj.p_payload = tx_payload; 
                message_signal = 1; //signal provision process sm.
                tx_packet_processor(&tx_packet_obj);                
            }
            else if(payload[1] == REPORT_GEAR_FW_VERSION)
            {
                //send it straight to MT76:
                tx_packet_obj.data_size = 7 + payload[2];
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_FW_VERSION;                
                memcpy(&tx_payload[0], gear_obj.gear_addr, 6); //Gear can't send address as characteristic payload size limit 20 
                tx_payload[6] = payload[2]; 
                memcpy(&tx_payload[7], &payload[3], payload[2]); 
                tx_packet_obj.p_payload = tx_payload; 
                message_signal = 2; //signal provision process sm.
                tx_packet_processor(&tx_packet_obj);                
            }
            else if(payload[1] == REPORT_GEAR_HW_VERSION)
            {
                //send it straight to MT76:
                tx_packet_obj.data_size = 24;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_HW_VERSION;
                memcpy(&tx_payload[0], gear_obj.gear_addr, 6); //Gear can't send address as characteristic payload size limit 20 
                tx_payload[6] = payload[2];
                memcpy(&tx_payload[7], &payload[3], 17); 
                tx_packet_obj.p_payload = tx_payload; 
                message_signal = 3; //signal provision process sm.
                tx_packet_processor(&tx_packet_obj);                
            }
            else if (payload[1] == REPORT_GEAR_TEMPERATURE)
            {
                //send it straight to MT76:
                tx_packet_obj.data_size = 10;
                tx_packet_obj.primary_header = COMMAND_PROTO_GEARS;
                tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_GEAR_TEMPERATURE;                
                memcpy(&tx_payload[0], &payload[2], 4); // 4 bytes of temp for float.
                memcpy(&tx_payload[4], gear_obj.gear_addr, 6); //Gear won't send address
                tx_packet_obj.p_payload = tx_payload; 
                message_signal = 4; //signal provision process sm.
                tx_packet_processor(&tx_packet_obj);                    
            }
        break;
        
        case COMMAND_PROTO_UTILITY:
        break;

        default:
            break;
    }
}

void payload_dequeue(void)
{
    ret_code_t err_code;

    uint8_t size;
    uint8_t data[256];

    if (m_bridge_busy == false)
    {
        err_code = byte_queue_pop(&size);
                  //APP_ERROR_CHECK(err_code);

        err_code = byte_queue_read(data, size);
                  //APP_ERROR_CHECK(err_code);

        if (err_code == NRF_SUCCESS)
            command_decoder(data, size);
        //else
           // report_device_busy();
    }
}

/**@brief Function for running the provision process state-machine.
 *
 * @details This function runs in a timer iteratively until terminal state.
 *
 * @param[in] p_tx_packet_obj        pointer to tx packet object (tx_packet_obj_t).
 */
void ble_packet_processor(tx_packet_obj_t * p_tx_packet_obj, uint8_t link_count)
{
    uint32_t       err_code;
    uint8_t size;
    uint8_t payload[MAX_PAYLOAD];
    uint8_t packet[MAX_PAYLOAD];


    payload[0] = p_tx_packet_obj->primary_header;
    payload[1] = p_tx_packet_obj->secondary_headers.value.secondary_header;
    memcpy(&payload[2], p_tx_packet_obj->p_payload, p_tx_packet_obj->data_size);

    size = packet_encoder(payload, (p_tx_packet_obj->data_size)+2, packet);

    for (uint32_t i = 0; i< link_count; i++) //NRF_SDH_BLE_CENTRAL_LINK_COUNT
    {
        ble_cus_service_cus_command_send(&m_ble_cus_service_client[i], packet, &size);
        // ERROR PROCESS?
    }
}

/**@brief Function for processing tx packet output to UART.
 *
 * @param[in] p_tx_packet_obj        pointer to tx packet object.
 */
void tx_packet_processor(tx_packet_obj_t * p_tx_packet_obj)
{
    uint32_t       err_code;
    uint8_t size;
    uint8_t payload[MAX_PAYLOAD];
    uint8_t packet[MAX_PAYLOAD];
    uint8_t tx_byte;


    payload[0] = p_tx_packet_obj->primary_header;
    payload[1] = p_tx_packet_obj->secondary_headers.value.secondary_header;
    memcpy(&payload[2], p_tx_packet_obj->p_payload, p_tx_packet_obj->data_size);

    size = packet_encoder(payload, (p_tx_packet_obj->data_size)+2, packet);
    
    for (int i = 0; i < size; i++)
    {
        tx_byte = packet[i];
        UNUSED_VARIABLE(app_uart_put(tx_byte));
    }
}

static void report_device_busy(void)
{
    tx_packet_obj_t tx_packet_obj;

    tx_packet_obj.data_size = 0;
    tx_packet_obj.primary_header = COMMAND_PROTO_UTILITY;
    tx_packet_obj.secondary_headers.header_type.gear_header = REPORT_BRIDGE_BUSY;
    tx_packet_obj.p_payload = NULL; 

    tx_packet_processor(&tx_packet_obj);
}

/**@brief Function for processing incoming bytes from UART to form a packet.
 */
void rx_packet_processor(void)
{
    uint32_t       err_code;
    uint8_t size;
    uint8_t payload[MAX_PAYLOAD];
    pkt_status ps = PKT_WAITING;
    uint8_t rx_byte;

    UNUSED_VARIABLE(app_uart_get(&rx_byte));
    if(m_dfu_mode == BLE_DFU_MODE_ACTIVE)
    {
        ps = packet_decoder_dfu_mode(rx_byte, payload, &size); //skips checksum etc.
    }
    else
    {
        ps = packet_decoder(rx_byte, payload, &size);
    }


    switch (ps)
    {
        case PKT_WAITING:
            NRF_LOG_INFO("PKT_WAITING");
            break;

        case PKT_PROCESSING:
//            NRF_LOG_INFO("PKT_PROCESSING");
            break;

        case PKT_RECEIVED:
            NRF_LOG_INFO("PKT_RECEIVED");
//            if (m_bridge_busy == false)
//              command_decoder(payload, size);
//            else
//              report_device_busy();
              
            err_code = byte_queue_push(&size);
                          APP_ERROR_CHECK(err_code);
            err_code = byte_queue_write(payload, size);
                          APP_ERROR_CHECK(err_code);
            break;

        case ACK_RECEIVED:
            break;

        case NAK_RECEIVED:
            break;

        case PKT_SIZE_ERR:
            NRF_LOG_INFO("PKT_SIZE_ERR");
            //feedback size error to MT76
            break;

        case PKT_CSUM_ERR:
            NRF_LOG_INFO("PKT_CSUM_ERR");
            //feedback checksum error to MT76
            break;

        default:
            break;
    }
}

/**@brief Function for processing incoming data from BLE notification.
 *
 * @param[in] p_payload        pointer to payload.
 * @param[in] length           length of the payload.
 */
static void notif_packet_processor(uint8_t const * p_payload, uint8_t length)
{
    pkt_status ps = PKT_WAITING;
    uint8_t payload[MAX_PAYLOAD];
    uint8_t size;
    uint8_t rx_byte;

    for (int i = 0; i < length; i++)
    {
         ps = packet_decoder(p_payload[i], payload, &size);
         if (ps == PKT_RECEIVED){break;}
    }

    switch (ps)
    {
        case PKT_WAITING:
            NRF_LOG_INFO("PKT_WAITING");
            break;

        case PKT_PROCESSING:
            NRF_LOG_INFO("PKT_PROCESSING");
            break;

        case PKT_RECEIVED:
            NRF_LOG_INFO("PKT_RECEIVED");
            notif_decoder(payload);
            break;

        case ACK_RECEIVED:
            break;

        case NAK_RECEIVED:
            break;

        case PKT_SIZE_ERR:
            NRF_LOG_INFO("PKT_SIZE_ERR");
            //feedback size error to BLE
            break;

        case PKT_CSUM_ERR:
            NRF_LOG_INFO("PKT_CSUM_ERR");
            //feedback checksum error to BLE
            break;

        default:
            break;
    }
}

/**@brief   Function for handling app_uart events.
 *
 * @details This function will receive a single character from the app_uart module and append it to
 *          a string. The string will be be sent over BLE when the last character received was a
 *          'new line' '\n' (hex 0x0A) or if the string has reached the maximum data length.
 */
void uart_event_handler(app_uart_evt_t * p_event)
{
    //static uint8_t data_array[256];
    static uint8_t index = 0;
    uint32_t       err_code;

    switch (p_event->evt_type)
    {
        case APP_UART_DATA_READY:
            //NRF_LOG_INFO("UART RX");
            //rx_packet_processor();
            break;

        case APP_UART_COMMUNICATION_ERROR:
            /*NRF_LOG_ERROR("Communication error occurred while handling UART: %08X", p_event->data.error_communication );
            if( p_event->data.error_communication & UART_ERRORSRC_BREAK_Msk )
            {
                NRF_LOG_ERROR("   Break");
            }
            if( p_event->data.error_communication & UART_ERRORSRC_FRAMING_Msk )
            {
                NRF_LOG_ERROR("   Framing");
            }
            if( p_event->data.error_communication & UART_ERRORSRC_PARITY_Msk )
            {
                NRF_LOG_ERROR("   Parity");
            }
            if( p_event->data.error_communication & UART_ERRORSRC_OVERRUN_Msk )
            {
                NRF_LOG_ERROR("   Overrun");
            }
            //APP_ERROR_HANDLER(p_event->data.error_communication);*/
            break;

        case APP_UART_FIFO_ERROR:
            //APP_ERROR_HANDLER(p_event->data.error_code);
            break;

        case APP_UART_TX_EMPTY:
            // transmission complete.
            break;

        default:
            break;
    }
}

/**@brief  Function for initializing the UART module.
 */
static void uart_init(void)
{
    uint32_t                     err_code;
    app_uart_comm_params_t const comm_params =
    {
//        #ifdef APP_PA_LNA
//        .rx_pin_no    = NRF_GPIO_PIN_MAP(1,11)/*RX_PIN_NUMBER*/,
//        .tx_pin_no    = NRF_GPIO_PIN_MAP(1,10)/*TX_PIN_NUMBER*/,
//        #else
        .rx_pin_no    = NRF_GPIO_PIN_MAP(1,11),
        .tx_pin_no    = NRF_GPIO_PIN_MAP(1,10),
//        #endif
        .rts_pin_no   = RTS_PIN_NUMBER,
        .cts_pin_no   = CTS_PIN_NUMBER,
        .flow_control = APP_UART_FLOW_CONTROL_DISABLED,
        .use_parity   = false,
        .baud_rate    = NRF_UART_BAUDRATE_115200
    };

    APP_UART_FIFO_INIT(&comm_params,
                       UART_RX_BUF_SIZE,
                       UART_TX_BUF_SIZE,
                       uart_event_handler,
                       APP_IRQ_PRIORITY_LOWEST,
                       err_code);
          APP_ERROR_CHECK(err_code);
}

/**@brief  Function for QSPI event handler.
 */
static void qspi_handler(nrf_drv_qspi_evt_t event, void * p_context)
{
    UNUSED_PARAMETER(event);
    UNUSED_PARAMETER(p_context);
    m_finished = true;
}

/**@brief  Function to configure the external flash memory.
 */
static void configure_memory()
{
    uint8_t temporary = 0x40;
    uint32_t err_code;

    nrf_qspi_cinstr_conf_t cinstr_cfg = {
        .opcode    = QSPI_STD_CMD_RSTEN,
        .length    = NRF_QSPI_CINSTR_LEN_1B,
        .io2_level = true,
        .io3_level = true,
        .wipwait   = true,
        .wren      = true
    };

    nrfx_qspi_config_t const qspi_config_params =
    {                                                                       \
        .xip_offset  = NRFX_QSPI_CONFIG_XIP_OFFSET,                         \
        .pins = {                                                           \
           .sck_pin     = NRF_GPIO_PIN_MAP(0,25),/*BSP_QSPI_SCK_PIN, */                               \
           .csn_pin     = NRF_GPIO_PIN_MAP(0,31),/*BSP_QSPI_CSN_PIN,   */                             \
           .io0_pin     = NRF_GPIO_PIN_MAP(0,20),/*BSP_QSPI_IO0_PIN,   */                             \
           .io1_pin     = NRF_GPIO_PIN_MAP(0,21),/*BSP_QSPI_IO1_PIN,   */                             \
           .io2_pin     = NRF_GPIO_PIN_MAP(0,22),/*BSP_QSPI_IO2_PIN,   */                              \
           .io3_pin     = NRF_GPIO_PIN_MAP(0,23),/*BSP_QSPI_IO3_PIN,   */                              \
        },                                                                  \
        .irq_priority   = (uint8_t)NRFX_QSPI_CONFIG_IRQ_PRIORITY,           \
        .prot_if = {                                                        \
            .readoc     = (nrf_qspi_readoc_t)NRFX_QSPI_CONFIG_READOC,       \
            .writeoc    = (nrf_qspi_writeoc_t)NRFX_QSPI_CONFIG_WRITEOC,     \
            .addrmode   = (nrf_qspi_addrmode_t)NRFX_QSPI_CONFIG_ADDRMODE,   \
            .dpmconfig  = false,                                            \
        },                                                                  \
        .phy_if = {                                                         \
            .sck_freq   = (nrf_qspi_frequency_t)NRFX_QSPI_CONFIG_FREQUENCY, \
            .sck_delay  = (uint8_t)NRFX_QSPI_CONFIG_SCK_DELAY,              \
            .spi_mode   = (nrf_qspi_spi_mode_t)NRFX_QSPI_CONFIG_MODE,       \
            .dpmen      = false                                             \
        },                                                                  \
    };

    err_code = nrf_drv_qspi_init(&qspi_config_params, qspi_handler, NULL);
                APP_ERROR_CHECK(err_code);

    // Send reset enable
    err_code = nrf_drv_qspi_cinstr_xfer(&cinstr_cfg, NULL, NULL);
                APP_ERROR_CHECK(err_code);

    // Send reset command
    cinstr_cfg.opcode = QSPI_STD_CMD_RST;
    err_code = nrf_drv_qspi_cinstr_xfer(&cinstr_cfg, NULL, NULL);
                APP_ERROR_CHECK(err_code);

    // Switch to qspi mode
    cinstr_cfg.opcode = QSPI_STD_CMD_WRSR;
    cinstr_cfg.length = NRF_QSPI_CINSTR_LEN_2B;
    err_code = nrf_drv_qspi_cinstr_xfer(&cinstr_cfg, &temporary, NULL);
                APP_ERROR_CHECK(err_code);
}

void qspi_extflash_dummy_test(void)
{
    // This is from qspi example project, here for reference.
    uint32_t i;
    uint32_t err_code;

    srand(0);
    for (i = 0; i < QSPI_DATA_SIZE; ++i)
    {
        m_buffer_tx[i] = (uint8_t)rand();
    }

    m_finished = false;
    err_code = nrf_drv_qspi_erase(NRF_QSPI_ERASE_LEN_64KB, 0);
    APP_ERROR_CHECK(err_code);
    WAIT_FOR_PERIPH();
    NRF_LOG_INFO("Process of erasing first block start");

    err_code = nrf_drv_qspi_write(m_buffer_tx, QSPI_DATA_SIZE, 0);
    APP_ERROR_CHECK(err_code);
    WAIT_FOR_PERIPH();
    NRF_LOG_INFO("Process of writing data start");

    err_code = nrf_drv_qspi_read(m_buffer_rx, QSPI_DATA_SIZE, 0);
    WAIT_FOR_PERIPH();
    NRF_LOG_INFO("Data read");

    NRF_LOG_INFO("Compare...");
    if (memcmp(m_buffer_tx, m_buffer_rx, QSPI_DATA_SIZE) == 0)
    {
        NRF_LOG_INFO("Data consistent");
    }
    else
    {
        NRF_LOG_INFO("Data inconsistent");
    }
}

static void skyworks_init(void)
{
#ifdef APP_PA_LNA
    nrf_gpio_cfg_output(APP_CPS_PIN);
    nrf_gpio_cfg_output(APP_CHL_PIN);
    nrf_gpio_pin_set(APP_CHL_PIN);
    nrf_gpio_pin_clear(APP_CPS_PIN); //enable
    pa_lna_init(APP_PA_PIN,APP_LNA_PIN);
#endif	
}

/**
* @brief Function for setting up LED softblink 
*/
static void led_softblink_setup(void)
{
    ret_code_t err_code;

    const led_sb_init_params_t led_sb_init_param = LED_SB_INIT_DEFAULT_PARAMS(BSP_LED_0_MASK); //LEDS_MASK

    err_code = led_softblink_init(&led_sb_init_param);
                APP_ERROR_CHECK(err_code);

    err_code = led_softblink_start(BSP_LED_0_MASK); //LEDS_MASK
                  APP_ERROR_CHECK(err_code);
}

int main(void)
{
    uint32_t err_code;

    // Initialize.
    uart_init();
    log_init();
    timer_init();
    //power_management_init();
    //ble_stack_init();
    //skyworks_init();
    //gap_params_init();
    //peer_manager_init();
    //gatt_init();
    //db_discovery_init();
    //cus_service_client_init();
    //dfu_service_client_init();
    //scan_init();

    // Ring LED setup
    nrf_gpio_cfg_output(LED_RING);
    nrf_gpio_cfg_output(LED_RING_SWITCH);
    nrf_gpio_pin_set(LED_RING_SWITCH);

    nrf_gpio_pin_set(LED_RING);
    nrf_delay_ms(500);
    nrf_gpio_pin_clear(LED_RING);
    nrf_delay_ms(500);
    nrf_gpio_pin_set(LED_RING);
    nrf_delay_ms(500);
    nrf_gpio_pin_clear(LED_RING);
    nrf_delay_ms(500);
    nrf_gpio_pin_set(LED_RING);
    nrf_delay_ms(500);
    nrf_gpio_pin_clear(LED_RING);
    nrf_delay_ms(500);


    // Start execution.
    NRF_LOG_INFO("AXIS Bridge");
    //instructions_print();

    //scan_filter_increment_peer(false);
    //app_timer_start(m_datascan_process_timer_id, DATASCAN_MODE_TIMEOUT, NULL);
    //app_timer_start(m_cmd_dq_process_timer_id, CMD_DQ_INTERVAL, NULL);

    // Setup QSPI for ext. flash
    //configure_memory();
    //qspi_extflash_dummy_test();
    // Enter main loop.
    while (true)
    {
        uint8_t cr;
        while (app_uart_get(&cr) != NRF_SUCCESS);
        //nrf_delay_ms(100);
        while (app_uart_put(cr) != NRF_SUCCESS);
        //while (app_uart_put('a') != NRF_SUCCESS);
        //nrf_delay_ms(100);
    }
}


/**
 * @}
 */
