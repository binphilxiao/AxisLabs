/**
 * \file
 * \author      Nabeel Ahmed
 */
#include "protocol_codec.h"
#include "nrf_log.h"

//extern void command_enqueue(uint8_t *command);

//void command_encoder(

//temp.
//void command_decoder(uint8_t *payload)
//{
//    bridge_protocol_primary_headers_t primaryHeader;
//    //uint8_t secondaryHeader;
//    
//    primaryHeader = payload[0];
//    //secondaryHeader = payload[1];
//
//    switch (primaryHeader)
//    {
//        case COMMAND_PROTO_GEARS:
//            if (payload[1] == SET_GEARS_POSITION)
//            {
//                NRF_LOG_INFO("Position Command");
//                scan_selection_state_set(SELECTION_SCAN_CONN);
//            }
//            
//            break;
//        
//        case COMMAND_PROTO_NETWORK:
//            if (payload[1] == DISCONNECT_ALL)
//            {
//                
//            }
//            break;
//
//        case COMMAND_PROTO_UTILITY:
//            break;       
//        
//        default:
//            break;
//    }
//}