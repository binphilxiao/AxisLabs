/**
 * \file
 * \author      Nabeel Ahmed
 */

#ifndef BLE_DFU_CLIENT_H__
#define BLE_DFU_CLIENT_H__

#include <stdint.h>
#include <stdbool.h>
#include "ble.h"
#include "ble_db_discovery.h"
#include "nrf_sdh_ble.h"

/**@brief   Macro for defining a ble_dfu instance.
 *
 * @param   _name   Name of the instance.
 * @hideinitializer
 */
#define BLE_DFU_BLE_OBSERVER_PRIO 2
#define BLE_DFU_DEF(_name)                                                                          \
static ble_dfu_service_client_t _name;                                                              \
NRF_SDH_BLE_OBSERVER(_name ## _obs,                                                                 \
                     BLE_DFU_BLE_OBSERVER_PRIO,                                                     \
                     ble_dfu_service_client_on_ble_evt, &_name)

/**@brief Nordic vendor-specific base UUID.
 * Below BLE_NORDIC_VENDOR_BASE_UUID, BLE_DFU_BUTTONLESS_CHAR_UUID, BLE_DFU_BUTTONLESS_BONDED_CHAR_UUID, DFU_SERVICE_UUID
 * are taken from ble_dfu.c
 */
#define BLE_NORDIC_VENDOR_BASE_UUID                 \
{{                                                  \
    0x50, 0xEA, 0xDA, 0x30, 0x88, 0x83, 0xB8, 0x9F, \
    0x60, 0x4F, 0x15, 0xF3, 0x00, 0x00, 0xC9, 0x8E  \
}}

#define DFU_SERVICE_UUID              0xFE59            /**< Nordic-specific DFU Service UUID. */
#define BLE_DFU_BUTTONLESS_CHAR_UUID        (0x0003)    /**< Value combined with vendor-specific base to create Unbonded Buttonless characteristic UUID. */
#define BLE_DFU_BUTTONLESS_BONDED_CHAR_UUID (0x0004)    /**< Value combined with vendor-specific base to create Bonded Buttonless characteristic. */
#define DFU_PACKET_UUID               0x0002
#define DFU_CONTROL_UUID              0x0001

// Type holding active/inactive BLE DFU mode.
typedef enum
{
    BLE_DFU_MODE_INACTIVE = 0, 
    BLE_DFU_MODE_ACTIVE
} ble_dfu_mode_t;

/**@brief DFU Service Client event type. */
typedef enum
{
    BLE_DFU_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE = 1,                    /**< Event indicating that the DFU service has been discovered at the peer. */
    BLE_DFU_SERVICE_CLIENT_EVT_TX_NOTIFICATION,                            /**< Event indicating that a notificaiton of the DFU Characteristic has been received from the peer.*/
    BLE_DFU_SERVICE_CLIENT_EVT_TX_INDICATION                              /**< Event indicating that a indication of the DFU Characteristic has been received from the peer.*/
} ble_dfu_service_client_evt_type_t;

/**@brief Structure containing the DFU data received from the peer. */
typedef struct
{
    uint8_t const * dfu_payload;                                 /**< DFU Payload */
    uint8_t length;                                              /**< Length of received data */
} ble_dfu_t;

/**@brief Structure containing the handles related to the DFU Service found on the peer. */
typedef struct
{
    uint16_t dfu_buttonless_cccd_handle;          /**< Handle of the CCCD of the DFU Buttonless characteristic. */
    uint16_t dfu_buttonless_handle;               /**< Handle of the DFU Buttonless characteristic as provided by the SoftDevice. */
    uint16_t dfu_control_cccd_handle;             /**< Handle of the CCCD of the DFU Control Point characteristic. */
    uint16_t dfu_control_handle;                  /**< Handle of the DFU Control Point characteristic as provided by the SoftDevice. */
    uint16_t dfu_packet_handle;                   /**< Handle of the DFU Packet characteristic as provided by the SoftDevice. */
} dfu_service_db_t;

/**@brief DFU Service Client event. */
typedef struct
{
    ble_dfu_service_client_evt_type_t evt_type;                   /**< Type of event. */
    uint16_t                        conn_handle;                  /**< Connection handle on which the event occured.*/
    union
    {
        ble_dfu_t                 dfu_data;       /**< DFU data received. This will be filled if the evt_type is @ref BLE_CUS_SERVICE_CLIENT_EVT_TX_NOTIFICATION.*/ 
        dfu_service_db_t         peer_db;         /**< DFU Service related handles found on the peer device. This will be filled if the evt_type is @ref BLE_CUS_CLIENT_EVT_DISCOVERY_COMPLETE.*/
    } params;
} ble_dfu_service_client_evt_t;

// Forward declaration of the ble_dfu_t type.
typedef struct ble_dfu_service_client_s ble_dfu_service_client_t;

/**@brief DFU Service event handler type. */
typedef void (* ble_dfu_service_client_evt_handler_t) (ble_dfu_service_client_t * p_dfu_service_client, ble_dfu_service_client_evt_t * p_evt);

/**@brief DFU Service Client structure */
struct ble_dfu_service_client_s
{
    uint16_t                              conn_handle;                 /**< Connection handle as provided by the SoftDevice. */
    dfu_service_db_t                      peer_dfu_service_db;         /**< Handles related to DFU Service on the peer*/
    ble_dfu_service_client_evt_handler_t  evt_handler;                 /**< Application event handler to be called when there is an event related to the DFU service. */
    uint8_t                               uuid_type;                   /**< UUID type. */
};

/**@brief DFU Service Client initialization structure. */
typedef struct
{
    ble_dfu_service_client_evt_handler_t evt_handler;  /**< Event handler to be called by the DFU Service Client module whenever there is an event related to the DFU Service. */
} ble_dfu_service_client_init_t;

/// Function definitions
uint32_t ble_dfu_service_client_init(ble_dfu_service_client_t * p_ble_dfu_service_client, ble_dfu_service_client_init_t * p_ble_dfu_service_client_init);

void ble_dfu_service_client_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context);

uint32_t ble_dfu_service_tx_indic_enable(ble_dfu_service_client_t * p_ble_dfu_service_client, bool enable);

uint32_t ble_dfu_service_tx_notif_enable(ble_dfu_service_client_t * p_ble_dfu_service_client, bool enable);

void ble_dfu_service_on_db_disc_evt(ble_dfu_service_client_t * p_ble_dfu_service_client, const ble_db_discovery_evt_t * p_evt);


uint32_t ble_dfu_service_client_handles_assign(ble_dfu_service_client_t *    p_ble_dfu_service_client,
                                  uint16_t         conn_handle,
                                  const dfu_service_db_t * p_peer_handles);

uint32_t ble_dfu_service_buttonless_command_send(ble_dfu_service_client_t * p_ble_dfu_service_client, uint8_t * command);

uint32_t ble_dfu_service_control_command_send(ble_dfu_service_client_t * p_ble_dfu_service_client, uint8_t * command, uint8_t size);

uint32_t ble_dfu_service_data_send(ble_dfu_service_client_t * p_ble_dfu_service_client, uint8_t * payload, uint8_t length);

#endif //BLE_DFU_CLIENT_H__