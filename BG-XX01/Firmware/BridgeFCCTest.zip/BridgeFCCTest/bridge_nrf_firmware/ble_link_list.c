/**
 * \file
 * \author      Nabeel Ahmed
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "ble_link_list.h"

ble_node_t *head = NULL;
ble_node_t *current = NULL;

//display the list
//void printList() {
//   struct node *ptr = head;
//   printf("\n[ ");
//	
//   //start from the beginning
//   while(ptr != NULL) {
//      printf("(%d,%d) ",ptr->key,ptr->data);
//      ptr = ptr->next;
//   }
//	
//   printf(" ]");
//}

//insert link at the first location
void insert_first_ble_node(uint8_t conn_handle, uint8_t ble_addr[]) {
   //create a link
   ble_node_t *link = (ble_node_t*) malloc(sizeof(ble_node_t));
	
   link->conn_handle = conn_handle;
   memcpy(link->ble_addr, ble_addr, 6);
	
   //point it to old first node
   link->next = head;
	
   //point first to new first node
   head = link;
}

//delete first item
ble_node_t* delete_first_ble_node(void) {

   //save reference to first link
   ble_node_t *tempLink = head;
	
   //mark next to first link as first 
   head = head->next;
	
   //return the deleted link
   return tempLink;
}

//is list empty
bool no_ble_nodes(void) {
   return head == NULL;
}

uint8_t count_ble_nodes() {
   uint8_t length = 0;
   ble_node_t *current;
	
   for(current = head; current != NULL; current = current->next) {
      length++;
   }
	
   return length;
}

//find a link with given conn_handle
ble_node_t* find_ble_node(uint8_t conn_handle) {

   //start from the first link
   ble_node_t* current = head;

   //if list is empty
   if(head == NULL) {
      return NULL;
   }

   //navigate through list
   while(current->conn_handle != conn_handle) {
	
      //if it is last node
      if(current->next == NULL) {
         return NULL;
      } else {
         //go to next link
         current = current->next;
      }
   }      
	
   //if gear_addr found, return the current Link
   return current;
}

//delete a link with given conn_handle
ble_node_t* delete_ble_node(uint8_t conn_handle) {

   //start from the first link
   ble_node_t* current = head;
   ble_node_t* previous = NULL;
	
   //if list is empty
   if(head == NULL) {
      return NULL;
   }

   //navigate through list
   while(current->conn_handle != conn_handle) {

      //if it is last node
      if(current->next == NULL) {
         return NULL;
      } else {
         //store reference to current link
         previous = current;
         //move to next link
         current = current->next;
      }
   }

   //found a match, update the link
   if(current == head) {
      //change first to point to next link
      head = head->next;
   } else {
      //bypass the current link
      previous->next = current->next;
   }    
	
   return current;
}

void sort_ble_nodes_list(void) {

   uint8_t i, j, k, temp_conn_handle;
   uint8_t temp_ble_addr[6];
   ble_node_t *current;
   ble_node_t *next;
	
   int size = count_ble_nodes();
   k = size ;
	
   for ( i = 0 ; i < size - 1 ; i++, k-- ) {
      current = head;
      next = head->next;
		
      for ( j = 1 ; j < k ; j++ ) {   

         if ( current->ble_addr > next->ble_addr ) {
            memcpy(temp_ble_addr, current->ble_addr, 6);
            memcpy(current->ble_addr, next->ble_addr, 6);
            memcpy(next->ble_addr, temp_ble_addr, 6);

            temp_conn_handle = current->conn_handle;
            current->conn_handle = next->conn_handle;
            next->conn_handle = temp_conn_handle;
         }
			
         current = current->next;
         next = next->next;
      }
   }   
}

void reverse_ble_nodes_list(ble_node_t** head_ref) {
   ble_node_t* prev   = NULL;
   ble_node_t* current = *head_ref;
   ble_node_t* next;
	
   while (current != NULL) {
      next  = current->next;
      current->next = prev;   
      prev = current;
      current = next;
   }
	
   *head_ref = prev;
}
