# Bridge_nRF_alpha_fw

---
 ### Overview

- This project is the firmware development of the nRF BLE module on the AXIS Gear V2 bridge platform.
- This file will document major implemented features, code details, programmer's notes, and technical details.
- These notes are useful for the firmware developer, developer for the bridge-side software (MT7688 OpenWRT software), and others.

## UART Protocol to MT7688
The UART interface is based on 115200 baud, 8 data bits, 1 stop bit, no parity bits, and no flow control.

## nRF-MT7688 Command Protocol

### Protocol Packet Definition:
| Header | Payload Size | Primary Header | Secondary Header | Data Payload | Checksum |
| --- | --- | --- | --- | --- | --- |
| 0xF5 | 1-byte | 1-byte | 1-byte | 0-250 bytes | 1 byte |

The Payload Size is the size of the payload which comprises Primary Header, Secondary Header, and Data Payload bytes.

**Payload**

| Primary Header | Secondary Header | Data Payload |
| --- | --- | --- |
| 1-byte | 1-byte | 0-250 bytes | 

**Checksum**

The checksum is a sum of the Primary Header, Secondary Header, and Data Payload bytes. This value will roll over beyond 255. the final remainder below 255 will be the checksum value.

### Primary Headers

- **COMMAND_PROTO_GEARS** : 0x01
- **COMMAND_PROTO_NETWORK** : 0x02
- **COMMAND_PROTO_UTILITY** : 0x03

### Secondary Headers

#### Gear Command Protocol (Primary Header: 0x01)

| Name | Secondary Header Byte | Sent by | Definition |
| --- | --- | --- | --- |
| SET_GEARS_POSITION | 0x01 | MT76 | Set position for group or group of gears |
| SET_GEAR_DFU_MODE  | 0x02 | MT76 | Set specific Gear into BLE DFU mode
| GET_GEARS_POSITION | 0x03 | MT76 | Get the position for specified Gear |
| GET_GEARS_BATTERY  | 0x04 | MT76 | Get the battery level for sepcified Gear |
| GEAR_GEARS_TEMPERATURE | 0x05 | MT76 | Get the temperature of specified Gear |
| GET_GEARS_INFO     | 0x06 | MT76 | Get the info of specified Gear (fw, hw, etc.) |
| REPORT_GEAR_POSITION | 0x07 | nRF | Report the position of specified Gear |
| REPORT_GEAR_BATTERY  | 0x08 | nRF | Report the battery level of specified Gear |
| REPORT_GEAR_TEMPERATURE | 0x09 | nRF | Report the temperature of specified Gear |
| REPORT_GEAR_INFO     | 0x0A | nRF | Report the info of the speified Gear - UNUSED |
| REPORT_NO_FEEDBACK   | 0x0B | nRF | Report no feedback received from Gear |
| REPORT_DFU_TARG_READY | 0x0C | nRF | Report DFU Target is now connected & ready |
| WRITE_DFU_CNTRL_CMD  | 0x0D | MT76 | Write DFU control point command |
| WRITE_DFU_PCKT_DATA  | 0x0E | MT76 | Write DFU packet data |
| REPORT_DFU_NOTIF_DATA  | 0x0F | nRF | Report received notification data from DFU target |
| SET_BLE_DFU_COMPLETE  | 0x10 | MT76 | Report end of DFU process |
| REPORT_GEAR_NAME  | 0x11 | nRF | Report Gear name |
| REPORT_GEAR_FW_VERSION  | 0x12 | nRF | Report Gear Firmware Version |
| REPORT_GEAR_HW_VERSION  | 0x13 | nRF | Report Gear Hardwarwe Version |
| REPORT_GEAR_PWR_TYPE  | 0x14 | nRF | Report Gear Power Type UNUSED |
| REPORT_GEAR_MACH_STATE  | 0x15 | nRF | Report Gear Machine State |
| REPORT_GEAR_POSITION_STATE  | 0x16 | nRF | Report Gear Postion State UNUSED|
| SET_GEAR_NAME | 0x17 | MT76 | Set Name of Gear |
	
** SET_GEARS_POSITION (PH:0x01, SH:01)**

The command to set position of specified Gear. Sent from MT76 to nRF. Group size is the number of Gears for this command, and BLE Addressses are listed consecutively. 
All Gears in a group command can only be commanded to the same position. Command for a single Gear will have group size of 1, and a single BLE address provided.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Position byte 0-64h |
| 1 | Group size  (1-20) |
| 2 | BLE Address 1 LSB |
| 3 | BLE Address 1|
| 4 | BLE Address 1|
| 5 | BLE Address 1|
| 6 | BLE Address 1|
| 7 | BLE Address 1 MSB |
| 8 | BLE Address 2 ... |

** GET_GEARS_INFO (PH: 0x01, SH: 0x06)**

The command to get power type, machine state, and position state data from Gear specified by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

** REPORT_GEAR_POSITION (PH: 0x01, SH: 0x07)**

The response from nRF periodically, or upon reciept of SET_GEARS_POSITION, obtained from the specified Gear by BLE address. Includes shade position percentage, and position state.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Position byte 0-64h |
| 1 | Position State |
| 2 | BLE Address LSB |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address |
| 7 | BLE Address MSB |

Position State:
Stopped Normal: 00
Moving Up (Top): 01
Moving Down (Bottom): 10
Stopped Obstacle: 11

** REPORT_GEAR_BATTERY (PH: 0x01, SH: 0x08)**

The response from the nRF periodically, obtained from the specified Gear by BLE address. Included Battery level in percentage, and power type.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Battery Level byte 0-64h |
| 1 | Power Type |
| 2 | BLE Address LSB |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address |
| 7 | BLE Address MSB |

Power Type:
Wall Plug: 00
Battery Charging: 01
Battery Not Charging: 10

** REPORT_GEAR_TEMPERATURE (PH: 0x01, SH: 0x09)**

The response from the nRF periodically, or upon reciept of GET_GEARS_TEMPERATURE, obtained from the specified Gear by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Temperature byte 0-64h |
| 1 | BLE Address LSB |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address MSB |

** REPORT_GEARS_INFO (PH: 0x01, SH: 0x0A)**

The response from the nRF periodically, or upon reciept of GET_GEARS_INFO, obtained from the specified Gear by BLE address.
Info byte consists of bit-defined Power Type, Machine State, and Position State.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Info byte 0-64h |
| 1 | BLE Address LSB |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address MSB |

Info Byte:

| Bit Index | Definition |
| --- | --- |
| 0 | Power Type|
| 1 | Power Type |
| 2 | Calibration State |
| 3 | Calibration State |
| 4 | Position State |
| 5 | Position State |
| 6 | Pair State |
| 7 | Reserved |

Power Type:
Wall Plug: 00
Battery Charging: 01
Battery Not Charging: 10

Calibration State:
Not Calibrated: 00
Calibration State Top: 01
Calibration State Bottom: 10
Calibrated: 11

Position State:
Stopped Normal: 00
Moving Up (Top): 01
Moving Down (Bottom): 10
Stopped Obstacle: 11

Pair State:
Pair mode inactive: 0
Pair mode active: 1

** SET_GEAR_DFU_MODE (PH: 0x01, SH: 0x02)**

Command from MT76 to begin the DFU process for device with provided BLE MAC address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

** REPORT_DFU_TARG_READY (PH: 0x01, SH: 0x0C)**

Report from nRF to MT76 stating that inteded device for DFU is connected and ready for the DFU process.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

** WRITE_DFU_CNTRL_CMD (PH: 0x01, SH: 0x0D)**

Command from MT76 for nRF to passthrough to the DFU Control Point characteristic on the DFU target in BLE bootloader mode.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | size of data packet |
| 1 | Control Command byte 0 |
| n | Control Command byte n-1 |

** WRITE_DFU_PCKT_DATA (PH: 0x01, SH: 0x0E)**

Firmware packet data payload for DFU process from MT76 to DFU target in BLE bootloader mode.

Payload:
Payload is a n-length data array. n maybe up to 256 bytes.

| Byte Index | Definition |
| --- | --- |
| 0 | size of data packet |
| 1 | data byte 0 |
| n | data byte n-1 |

** REPORT_DFU_NOTIF_DATA (PH: 0x01, SH: 0x0F)**

Report from nRF of notification data received from DFU target in BLE bootloader mode.

Payload:
Payload is a n-length data array. n maybe up to 256 bytes.

| Byte Index | Definition |
| --- | --- |
| 0 | size of response |
| 1 | data byte 0 |
| n | data byte n-1 |

** SET_BLE_DFU_COMPLETE (PH: 0x01, SH: 0x10)**

Command from MT76 to end DFU mode at Bridge nRF and exit DFU process.

Payload:
No Payload.

** REPORT_GEAR_NAME (PH: 0x01, SH: 0x11)**

The device name response from the nRF periodically upon connection to Gear specified Gear by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |
| 6 | Name length n |
| 7 | Name character 0 |
| 7+(n-1) | Name character n-1|


** SET_GEAR_NAME (PH: 0x01, SH: 0x17)**

The set device name command originating from MT76 bridge to specified Gear by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |
| 6 | Name length n |
| 7 | Name character 0 |
| 7+(n-1) | Name character n-1|

** REPORT_GEAR_FW_VERSION (PH: 0x01, SH: 0x12)**

The device firmware version response from the nRF periodically upon connection to Gear specified Gear by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |
| 6 | FW string length n |
| 7 | FW character 0 |
| n+7 | FW character n-1 |

Format:
X.Y.Z following semantic versioning. 

** REPORT_GEAR_HW_VERSION (PH: 0x01, SH: 0x13)**

The device hardware version response from the nRF periodically upon connection to Gear specified Gear by BLE address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |
| 6 | HW string length n |
| 7 | HW character 0 |
| n+7 | HW character n-1 |

Format of HW Version String in order:
1 BYTE: Motor type (read the pin)
2 BYTES: Board revision
14 BYTES: Serial number (MMMMWWYYSSSSSS Where MMMM indicate the product model, WW Week of year of production, YY year of production, SSSSSS Serial number)

** REPORT_GEAR_PWR_TYPE (PH: 0x01, SH: 0x14)**

The response from the nRF periodically, or upon reciept of GET_GEARS_INFO, obtained from the specified Gear by BLE address.
Data byte consists of bit-defined Power Type. UNUSED. POWER TYPE NOW COMBINED WITH REPORT_GEAR_BATTERY PAYLOAD.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Pwr type |
| 1 | BLE Address LSB |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address MSB |

Power Type:
Wall Plug: 00
Battery Charging: 01
Battery Not Charging: 10

** REPORT_GEAR_MACH_STATE (PH: 0x01, SH: 0x15)**

The response from the nRF periodically, or upon reciept of GET_GEARS_INFO, obtained from the specified Gear by BLE address.
Data byte consists of bit-defined Machine State.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Machine State |
| 1 | BLE Address LSB |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address MSB |

Calibration State:
Not Calibrated: 00
Calibration State Top: 01
Calibration State Bottom: 10
Calibrated: 11

** REPORT_GEAR_POSITION_STATE (PH: 0x01, SH: 0x16)**

The response from the nRF periodically, or upon reciept of GET_GEARS_INFO, obtained from the specified Gear by BLE address.
Data byte consists of bit-defined Position State. UNUSED. POSITION STATE NOW INCLUDED IN REPORT_GEAR_POSITION PAYLOAD.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | Position State |
| 1 | BLE Address LSB |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address |
| 6 | BLE Address MSB |

Position State:
Stopped Normal: 00
Moving Up (Top): 01
Moving Down (Bottom): 10
Stopped Obstacle: 11

#### Network Command Protocol (Primary Header: 0x02)

| Name | Secondary Header Byte | Sent by | Definition |
| --- | --- | --- | --- |
| SET_PROVISION_MODE    | 0x01 | MT76 | Set the bridge nRF to provisioning mode - scan all devices with name AXIS Gear V2 |
| GET_PROVISIONED_GEARS | 0x02 | MT76 | Get a list of provisioned Gear UNUSED |
| GET_ONLINE_GEARS      | 0x03 | MT76 | Get a list of Gears online (previously provisioned) UNUSED |
| DELETE_PROVISIONED_GEAR    | 0x04 | MT76 | Delete a specific Gear - delete bonding information specified Gear |
| CONNECT_SPECIFIED_GEAR     | 0x05 | MT76 | Connect to a specific Gear and do nothing |
| DISCONNECT_ALL             | 0x06 | MT76 | Disconnect from all connected Gears |
| REPORT_SCANNED_GEAR        | 0x07 | nRF | Report of Gears by BLE address found while scanning during provisioning mode |
| REPORT_GEAR_NOT_FOUND	     | 0x08 | nRF | Report Gear not found during normal network scanning |
| REPORT_PROVISIONED_GEARS   | 0x09 | nRF | Report a list of all currently provisioned Gears  |
| REPORT_CONNECT_PROV_SUCCESS  | 0x0A | nRF | Report successful provisioning to Gear of specified BLE Address |
| REPORT_ONLINE_GEARS        | 0x0B | nRF | Report list of provisioned Gears that are online |
| REPORT_DELETE_SUCCESS		 | 0x0C | nRF | Report successfully deleted specified Gear/Peer (w/Address) |
| REPORT_DELETE_ERROR		 | 0x0D | nRF | Report bond delete error/failed due for any reason. |


**SET_PROVISION_MODE (PH: 0x02, SH: 0x02)**

Command from MT76 to set the nRF into provisioning mode. It will scan for devices of name "AXIS Gear V2" and pair mode flag enabled in scan response data.
Will report back to MT76 (REPORT_SCANNED_GEAR).

No Payload.

** DELETE_PROVISIONED_GEAR ( PH:0x02, SH: 0x04)**

Command from MT76 to nRF to delete bonding info of specified Gear by BLE Address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

**CONNECT_SPECIFIED_GEAR (PH: 0x02, SH: 0x05)**

Command from MT76 to connect to Gear device of given BLE Address.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

**DISCONNECT_ALL (PH: 0x02, SH: 0x06)**

Command from MT76 to disconnect nRF from all peers (Gears) it's connected to.

No Payload

**REPORT_SCANNED_GEAR (PH: 0x02, SH:0x07)**

On receipt of the SET_PROVISIONING_MODE from MT76, the nRF will start reporting any found "AXIS Gear V2" devices with this response packet.

Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |

**REPORT_CONNECT_PROV_SUCCESS (PH: 0x02, SH: 0x0A)**

Response from nRF on successful connection and secure pairing of peer Gear device. This is in resposne to CONNECT_SPECIFIED_GEAR.


Payload:

| Byte Index | Definition |
| --- | --- |
| 0 | BLE Address LSB |
| 1 | BLE Address |
| 2 | BLE Address |
| 3 | BLE Address |
| 4 | BLE Address |
| 5 | BLE Address MSB |


#### Utility Command Protocol (Primary Header: 0x03)

| Name | Secondary Header Byte | Sent by | Definition |
| --- | --- | --- | --- |
| SET_GEAR_FACTORY_RESET | 0x01 | MT76-nRF | Facory Reset Gear. Delete all information from flash. |
| SET_GEAR_DELETE_BOND | 0x02 | nRF-Gear | Delete bond of specified Central device. |
| SET_GEAR_BRIDGED_MODE | 0x03 | nRF-Gear | Set Gear to bridge mode. Does not allow any other Central or Pair Mode untril factory reset. |
| SET_NRF_SERIAL_DFU    | 0x04 | MT76-nRF | Set Bridge nRF to UART DFU mode - will causes system reset. |
| REPORT_BRIDGE_BUSY    | 0x05 | nRF-MT76 | Report nRF is busy with a process. Wait before requesting new command process. |
| REPORT_FDBK_CSUM_ERR | 0x06 | nRF-MT76 | Report checksum error from protocol decoder. |
| REPORT_FDBK_SIZE_ERR | 0x07 | nRF-MT76 | Report payload size error from protocol decoder. |

**SET_NRF_SERIAL_DFU (PH: 0x03, SH: 0x04)**

The Serial DFU utility of MT76 will send this frame to the nRF on bridge to begin it's serial (UART) DFU process. 

No Paylod.

## Provisioning - Protocol Commands Process

1. Send SET_PROVISION_MODE command. MT76-nRF.
2. <SUPERCEDED> Receive all found Gear BLE devices by REPORT_SCANNED_GEAR. nRF-MT76.
3. <SUPERCEDED> Connect to one of the founds Gears by BLE Adderss using CONNECT_SPECIFIED_GEAR. MT76-nRF.
2. User presses Pair button on Gear device. Gear advertises with Pair Mode flag in Manuf. Data field.
3. Bridge nRF finds Pair Mode Gear and reports REPORT_SCANNED_GEAR. nRF-MT76.
4. Bridge nRF automatic provision process by connecting, bonding, set Gear to bridged-mode by SET_GEAR_BRIDGED_MODE (automatic).
5. Recieve confirmation of successful connection and security pairing by REPORT_CONNECT_PROV_SUCCESS. nRF-MT76.
6. At this point nRF is disconnected from the paired Gear. 

## Connect & Control Gear Position - Protocol Commands Process

1. Send a SET_GEARS_POSITION with specified position, group size (1-20 Gears) and Gear BLE Address or Addresses consecutively for a group size more than 1. MT76-nRF.
2. Recieve a REPORT_GEAR_POSITION with specified position and Gear BLE Addrss as confirmation. nRF-MT76.

## Delete Provisioned Gear

1. Send DELETE_PROVISIONED_GEAR command to nRF with payload of BLE Address of Gear to be deleted.
2. Bridge nRF will connect to Gear, send SET_GEAR_DELETE_BOND command to Gear, Gear will disconnect and delete Bridge bonding info. Bridge nRF will delete bond info.
3. Recieve REPORT_DELETE_SUCCESS confirmation message with payload of Gear Address that was deleted. 

## Receive periodic Gear scan-response or asynchronous data

This mode is the default mode of the Bridge nRF module. This mode is active at start-up, and at termination of processes such as provisioning, position command, etc.

1. Periodically recieve a REPORT_GEAR_BATTERY(including power type), REPORT_GEAR_POSITION(including position state), and REPORT_GEAR_MACH_STATE. nRF-MT76. 
2. Upon first connection after completion of DFU of Gear recieve a REPORT_GEAR_FW_VERSION.
3. If Gear name exists during commissioning to Bridge - upon completion of commissioning recieve REPORT_GEAR_NAME.

## BLE DFU Process

This process will update the firmware using BLE of Gear V2 / peripheral devices paired to the bridge.

1. Send SET_GEAR_DFU_MODE command containing the BLE address of device to be updated.
2. Bridge nRF will scan, connect and command the target device into DFU mode, it will reset into BLE bootloader mode, and Bridge nRF will reconnect. 
3. Bridge nRF will send REPORT_DFU_TARG_READY to MT76 reporting that DFU Target is now ready in BLE bootloader mode.
4. Bridge MT76 may now send WRITE_DFU_CNTRL_CMD containing control point commands, or WRITE_DFU_PCKT_DATA containing firmware image data packets. 
5. Bridge nRF will pass-through control point and data packets to the DFU target that is connected in BLE bootlaoder mode.
6. Any BLE notification data received by the Bridge nRF will be sent to MT76 in a REPORT_DFU_NOTIF_DATA report. 

## UART DFU Process

This process will update the firmware of the Bridge nRF device over UART from MT76. 

1. Send SET_NRF_SERIAL_DFU from MT76.
2. Bridge nRF will reboot into UART bootloader mode. 
3. Follow Nordic UART bootloader process. 

## NOT IMPLEMENTED:
SET_GEAR_FACTORY_RESET
GET_GEARS_POSITION
GET_GEARS_BATTERY
GET_GEARS_TEMPERATURE
REPORT_GEAR_TEMPERATURE
REPORT_GEAR_PWR_TYPE
REPORT_GEAR_POSITION_STATE
GET_PROVISIONED_GEARS
GET_ONLINE_GEARS