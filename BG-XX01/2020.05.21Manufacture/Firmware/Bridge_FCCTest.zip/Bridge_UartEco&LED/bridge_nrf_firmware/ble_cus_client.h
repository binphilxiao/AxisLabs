/**
 * \file
 * \author      Nabeel Ahmed
 */

#ifndef BLE_CUS_CLIENT_H__
#define BLE_CUS_CLIENT_H__

#include <stdint.h>
#include <stdbool.h>
#include "ble.h"
#include "ble_db_discovery.h"
#include "nrf_sdh_ble.h"

/**@brief   Macro for defining a ble_cus instance.
 *
 * @param   _name   Name of the instance.
 * @hideinitializer
 */
#define BLE_CUS_BLE_OBSERVER_PRIO 2
#define BLE_CUS_DEF(_name)                                                                          \
static ble_cus_service_client_t _name;                                                              \
NRF_SDH_BLE_OBSERVER(_name ## _obs,                                                                 \
                     BLE_CUS_BLE_OBSERVER_PRIO,                                                     \
                     ble_cus_service_client_on_ble_evt, &_name)

/**@brief   Macro for defining multiple ble_cus instances.
 *
 * @param   _name   Name of the instances.
 * @param   _cnt    Number of instances to define.
 * @hideinitializer
 */
#define BLE_CUS_ARRAY_DEF(_name, _cnt)                                                              \
static ble_cus_service_client_t _name[_cnt];                                                        \
NRF_SDH_BLE_OBSERVERS(_name ## _obs,                                                                 \
                     BLE_CUS_BLE_OBSERVER_PRIO,                                                     \
                     ble_cus_service_client_on_ble_evt, &_name, _cnt)

#define CUSTOM_SERVICE_UUID_BASE         {0x38, 0x82, 0x38, 0x01, 0x39, 0x4A, 0xCD, 0xB4, \
                                          0x8B, 0x49, 0xBD, 0xB0, 0x7D, 0xB4, 0x2F, 0xA7}

#define CUSTOM_SERVICE_UUID               0x2800
#define CUSTOM_TX_CHAR_UUID               0x2801
#define CUSTOM_RX_CHAR_UUID               0x2802

/**@brief Custom Service Client event type. */
typedef enum
{
    BLE_CUS_SERVICE_CLIENT_EVT_DISCOVERY_COMPLETE = 1,                    /**< Event indicating that the custom service has been discovered at the peer. */
    BLE_CUS_SERVICE_CLIENT_EVT_TX_NOTIFICATION                            /**< Event indicating that a notificaiton of the TX Characteristic has been received from the peer.*/
} ble_cus_service_client_evt_type_t;

/**@brief Structure containing the Tx value received from the peer. */
typedef struct
{
    uint8_t const * tx_value;                                          /**< Tx Payload */
    uint8_t length;                                              /**< Length of received data */
} ble_tx_t;

/**@brief Structure containing the handles related to the Custom Service found on the peer. */
typedef struct
{
    uint16_t cus_tx_cccd_handle;                  /**< Handle of the CCCD of the tx characteristic. */
    uint16_t cus_tx_handle;                   /**< Handle of the cus tx characteristic as provided by the SoftDevice. */
    uint16_t cus_rx_handle;                   /**< Handle of the cus rx characteristic as provided by the SoftDevice. */
} cus_service_db_t;

/**@brief Custom Service Client event. */
typedef struct
{
    ble_cus_service_client_evt_type_t evt_type;                           /**< Type of event. */
    uint16_t                        conn_handle;                  /**< Connection handle on which the event occured.*/
    union
    {
        ble_tx_t                 tx;              /**< Tx value received. This will be filled if the evt_type is @ref BLE_CUS_SERVICE_CLIENT_EVT_TX_NOTIFICATION.*/ 
        cus_service_db_t         peer_db;         /**< Custom Service related handles found on the peer device. This will be filled if the evt_type is @ref BLE_CUS_CLIENT_EVT_DISCOVERY_COMPLETE.*/
    } params;
} ble_cus_service_client_evt_t;

// Forward declaration of the ble_cus_t type.
typedef struct ble_cus_service_client_s ble_cus_service_client_t;


/**@brief Custom Service event handler type. */
typedef void (* ble_cus_service_client_evt_handler_t) (ble_cus_service_client_t * p_cus_service_client, ble_cus_service_client_evt_t * p_evt);

/**@brief Custom Service Client structure */
struct ble_cus_service_client_s
{
    uint16_t                              conn_handle;                 /**< Connection handle as provided by the SoftDevice. */
    cus_service_db_t                      peer_cus_service_db;        /**< Handles related to Custom Service on the peer*/
    ble_cus_service_client_evt_handler_t  evt_handler;                 /**< Application event handler to be called when there is an event related to the Custom service. */
    uint8_t                               uuid_type;                   /**< UUID type. */
};

/**@brief Custom Service Client initialization structure. */
typedef struct
{
    ble_cus_service_client_evt_handler_t evt_handler;  /**< Event handler to be called by the Custom Service Client module whenever there is an event related to the Custom Service. */
} ble_cus_service_client_init_t;



uint32_t ble_cus_service_client_init(ble_cus_service_client_t * p_ble_cus_service_client, ble_cus_service_client_init_t * p_ble_cus_service_client_init);

void ble_cus_service_client_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context);

uint32_t ble_cus_service_tx_notif_enable(ble_cus_service_client_t * p_ble_cus_service_client, bool enable);

void ble_cus_service_on_db_disc_evt(ble_cus_service_client_t * p_ble_cus_service_client, const ble_db_discovery_evt_t * p_evt);


uint32_t ble_cus_service_client_handles_assign(ble_cus_service_client_t *    p_ble_cus_service_client,
                                  uint16_t         conn_handle,
                                  const cus_service_db_t * p_peer_handles);

//uint32_t ble_cus_service_tx_cmd_send(ble_cus_service_client_t * p_ble_cus_service_client, uint8_t setting);
uint32_t ble_cus_service_cus_command_send(ble_cus_service_client_t * p_ble_cus_service_client, uint8_t * payload, uint8_t * length);



#endif //BLE_CUS_CLIENT_H__